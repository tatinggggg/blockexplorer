#!/bin/bash
# BlockXplorer Quick Start

echo "⬡ BlockXplorer Setup"
echo "===================="

# Backend
echo ""
echo "→ Installing backend dependencies..."
cd backend && npm install

echo ""
echo "→ Installing frontend dependencies..."
cd ../frontend && npm install

echo ""
echo "✓ Setup complete!"
echo ""
echo "Start backend:   cd backend  && npm run dev   (port 3001)"
echo "Start frontend:  cd frontend && npm run dev   (port 5173)"
echo ""
echo "Login: admin / @Ak3s1t4m!"
echo ""
echo "Ensure MongoDB is running:"
echo "  Local:  mongod --dbpath /data/db"
echo "  Atlas:  Update MONGODB_URI in backend/.env"
