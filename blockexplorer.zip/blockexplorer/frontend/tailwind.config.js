/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        dark: {
          900: '#050810',
          800: '#080c18',
          700: '#0d1526',
          600: '#121c35',
          500: '#1a2540',
          400: '#243050',
          300: '#2e3d63',
        },
        brand: {
          cyan: '#00d4ff',
          green: '#00ff9d',
          orange: '#ff6b35',
          purple: '#b06dff',
          yellow: '#ffb347',
          red: '#ff4757',
        }
      },
      fontFamily: {
        mono: ['"Share Tech Mono"', 'monospace'],
        sans: ['"Rajdhani"', 'sans-serif'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'fade-in': 'fadeIn 0.3s ease',
        'slide-in': 'slideIn 0.3s ease',
      },
      keyframes: {
        fadeIn: { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'none' } },
        slideIn: { from: { opacity: '0', transform: 'translateX(-12px)' }, to: { opacity: '1', transform: 'none' } },
      },
    },
  },
  plugins: [],
}
