import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useWS } from '../contexts/WSContext';

const navItems = [
  { to: '/', label: 'Home', icon: '⬡', exact: true, desc: 'Blocks & Mempool' },
  { to: '/address', label: 'Address', icon: '◎', desc: 'Address Lookup' },
  { to: '/tx', label: 'Transaction', icon: '⇄', desc: 'TX Lookup' },
  { to: '/devtools', label: 'Dev Tools', icon: '⚙', desc: 'Builder & Tools' },
  { to: '/admin', label: 'Admin', icon: '⬒', desc: 'Dashboard' },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const { connected } = useWS();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <aside className="w-56 min-h-screen bg-dark-800 border-r border-dark-500 flex flex-col shrink-0">
      {/* Logo */}
      <div className="px-5 py-4 border-b border-dark-500">
        <div className="font-mono text-brand-cyan text-base tracking-widest glow-cyan flex items-center gap-2">
          <span className="text-xl">⬡</span>
          <span>BLOCK<span className="text-gray-300">XPLORER</span></span>
        </div>
        <div className="text-xs text-gray-600 font-mono mt-1 tracking-wider">DEVELOPER TOOLS</div>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-4 px-3 space-y-1">
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.exact}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-md transition-all duration-150 group
               ${isActive
                 ? 'bg-brand-cyan/10 text-brand-cyan border border-brand-cyan/25 shadow-lg shadow-brand-cyan/5'
                 : 'text-gray-500 hover:text-gray-200 hover:bg-dark-700 border border-transparent'
               }`
            }
          >
            {({ isActive }) => (
              <>
                <span className={`text-base w-5 text-center ${isActive ? 'text-brand-cyan' : ''}`}>
                  {item.icon}
                </span>
                <div>
                  <div className={`text-sm font-bold tracking-wide font-sans ${isActive ? '' : ''}`}>
                    {item.label}
                  </div>
                  <div className="text-xs text-gray-600 font-mono">{item.desc}</div>
                </div>
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Status & User */}
      <div className="border-t border-dark-500 p-3 space-y-2">
        {/* WS Status */}
        <div className="flex items-center gap-2 px-2 py-1.5 bg-dark-700 rounded">
          <div className={`w-2 h-2 rounded-full ${connected ? 'bg-brand-green shadow-sm shadow-brand-green' : 'bg-brand-red'} animate-pulse`} />
          <span className="font-mono text-xs text-gray-500">
            WS {connected ? 'Connected' : 'Disconnected'}
          </span>
        </div>

        {/* User */}
        <div className="flex items-center justify-between px-2 py-1.5 bg-dark-700 rounded">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-brand-cyan/20 flex items-center justify-center text-xs text-brand-cyan font-bold">
              {user?.username?.[0]?.toUpperCase()}
            </div>
            <span className="font-mono text-xs text-gray-400">{user?.username}</span>
          </div>
          <button
            onClick={handleLogout}
            className="text-xs text-gray-600 hover:text-brand-red transition-colors font-mono"
            title="Logout"
          >
            ⏻
          </button>
        </div>
      </div>
    </aside>
  );
}
