import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { WSProvider } from './contexts/WSContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Home from './pages/Home';
import AddressLookup from './pages/AddressLookup';
import TransactionLookup from './pages/TransactionLookup';
import DevTools from './pages/DevTools';
import AdminDashboard from './pages/AdminDashboard';

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-dark-900">
      <div className="text-brand-cyan font-mono text-sm animate-pulse">Initializing…</div>
    </div>
  );
  return user ? children : <Navigate to="/login" replace />;
}

function AppRoutes() {
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/" element={
        <ProtectedRoute>
          <WSProvider>
            <Layout>
              <Home />
            </Layout>
          </WSProvider>
        </ProtectedRoute>
      } />
      <Route path="/address" element={
        <ProtectedRoute>
          <WSProvider>
            <Layout>
              <AddressLookup />
            </Layout>
          </WSProvider>
        </ProtectedRoute>
      } />
      <Route path="/tx" element={
        <ProtectedRoute>
          <WSProvider>
            <Layout>
              <TransactionLookup />
            </Layout>
          </WSProvider>
        </ProtectedRoute>
      } />
      <Route path="/devtools" element={
        <ProtectedRoute>
          <WSProvider>
            <Layout>
              <DevTools />
            </Layout>
          </WSProvider>
        </ProtectedRoute>
      } />
      <Route path="/admin" element={
        <ProtectedRoute>
          <WSProvider>
            <Layout>
              <AdminDashboard />
            </Layout>
          </WSProvider>
        </ProtectedRoute>
      } />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <div className="scanline" />
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
