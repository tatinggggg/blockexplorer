import { useState } from 'react';
import axios from 'axios';

export default function DevTools() {
  const [activeTab, setActiveTab] = useState('generator');

  const tabs = [
    { id: 'generator', label: '⊕ Address Generator' },
    { id: 'utxo', label: '◇ UTXO List' },
    { id: 'fee', label: '⊘ Fee Calculator' },
    { id: 'rawtx', label: '⬒ Raw TX Builder' },
    { id: 'mempool', label: '◉ Mempool View' },
  ];

  return (
    <div className="p-6 animate-fade-in">
      <div className="mb-6">
        <h1 className="font-sans font-bold text-xl text-gray-100">Developer Tools</h1>
        <p className="text-xs text-gray-500 font-mono mt-0.5">Address generation · UTXO explorer · Fee calculator · TX builder</p>
      </div>

      {/* Tab bar */}
      <div className="flex flex-wrap gap-1 mb-6 bg-dark-800 rounded-lg p-1 border border-dark-500">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`px-4 py-2 rounded text-xs font-bold tracking-wider font-sans uppercase transition-all
              ${activeTab === t.id
                ? 'bg-brand-cyan/10 text-brand-cyan border border-brand-cyan/30'
                : 'text-gray-500 hover:text-gray-300 border border-transparent'}`}>
            {t.label}
          </button>
        ))}
      </div>

      <div className="animate-fade-in">
        {activeTab === 'generator' && <AddressGenerator />}
        {activeTab === 'utxo' && <UTXOList />}
        {activeTab === 'fee' && <FeeCalculator />}
        {activeTab === 'rawtx' && <RawTxBuilder />}
        {activeTab === 'mempool' && <MempoolView />}
      </div>
    </div>
  );
}

// ── Address Generator ────────────────────────────────────────────────────────
function AddressGenerator() {
  const [chain, setChain] = useState('BTC');
  const [count, setCount] = useState(5);
  const [addresses, setAddresses] = useState([]);
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/api/admin/generate-addresses', { chain, count });
      setAddresses(res.data.addresses || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const exportCSV = () => {
    if (!addresses.length) return;
    const headers = chain === 'BTC'
      ? ['address', 'privateKey', 'wif']
      : ['address', 'privateKey'];
    const rows = addresses.map(a =>
      chain === 'BTC'
        ? [a.address, a.privateKey, a.wif]
        : [a.address, a.privateKey]
    );
    const csv = [headers, ...rows].map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${chain}_addresses_${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="space-y-5">
      <div className="card">
        <div className="card-header">
          <span className="text-brand-green">⊕</span>
          <span className="section-title">Address Generator</span>
        </div>
        <div className="p-5">
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <label className="label">Chain</label>
              <select className="input" value={chain} onChange={e => { setChain(e.target.value); setAddresses([]); }}>
                <option value="BTC">Bitcoin (BTC)</option>
                <option value="ETH">Ethereum (ETH)</option>
                <option value="BSC">BNB Chain (BSC)</option>
              </select>
            </div>
            <div className="w-32">
              <label className="label">Count (max 1000)</label>
              <input className="input" type="number" min={1} max={1000} value={count} onChange={e => setCount(e.target.value)} />
            </div>
            <button onClick={generate} disabled={loading} className="btn-success shrink-0">
              {loading ? '⟳ Generating…' : '⊕ Generate'}
            </button>
            {addresses.length > 0 && (
              <button onClick={exportCSV} className="btn-primary shrink-0">
                ↓ Export CSV
              </button>
            )}
          </div>
        </div>
      </div>

      {addresses.length > 0 && (
        <div className="card">
          <div className="card-header">
            <span className="text-brand-green">◎</span>
            <span className="section-title flex-1">Generated Addresses</span>
            <span className="badge badge-green">{addresses.length}</span>
          </div>
          <div className="overflow-x-auto max-h-96 overflow-y-auto">
            <table className="w-full">
              <thead className="sticky top-0">
                <tr>
                  <th className="table-head">#</th>
                  <th className="table-head">Address</th>
                  <th className="table-head">Private Key</th>
                  {chain === 'BTC' && <th className="table-head">WIF</th>}
                </tr>
              </thead>
              <tbody>
                {addresses.map((a, i) => (
                  <tr key={i} className="hover:bg-dark-700/30">
                    <td className="table-cell text-gray-600">{i + 1}</td>
                    <td className="table-cell"><span className="addr text-xs">{a.address}</span></td>
                    <td className="table-cell font-mono text-xs text-gray-500 max-w-xs truncate">{a.privateKey}</td>
                    {chain === 'BTC' && <td className="table-cell font-mono text-xs text-gray-500">{a.wif}</td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ── UTXO List ─────────────────────────────────────────────────────────────────
function UTXOList() {
  const [search, setSearch] = useState({ address: '', chain: 'BTC' });
  const [utxos, setUtxos] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetch = async (e) => {
    e.preventDefault();
    if (!search.address.trim()) return;
    setLoading(true);
    setError('');
    try {
      const res = await axios.get(`/api/utxo/${search.chain}/${search.address.trim()}`);
      setUtxos(res.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="card">
        <div className="card-header">
          <span className="text-brand-yellow">◇</span>
          <span className="section-title">UTXO Explorer</span>
          <span className="badge badge-cyan ml-auto">SORTED BY AMOUNT ↓</span>
        </div>
        <form onSubmit={fetch} className="p-5">
          <div className="flex gap-3">
            <select className="input w-28 shrink-0" value={search.chain} onChange={e => setSearch(p => ({ ...p, chain: e.target.value }))}>
              <option>BTC</option>
              <option>ETH</option>
              <option>BSC</option>
            </select>
            <input className="input flex-1" placeholder="Enter address…" value={search.address} onChange={e => setSearch(p => ({ ...p, address: e.target.value }))} />
            <button type="submit" disabled={loading} className="btn-primary shrink-0">
              {loading ? '⟳' : '→ Fetch UTXOs'}
            </button>
          </div>
        </form>
      </div>

      {error && <div className="px-4 py-2 bg-brand-red/10 border border-brand-red/30 rounded text-brand-red font-mono text-xs">✗ {error}</div>}

      {utxos && (
        <div className="card animate-fade-in">
          <div className="card-header">
            <span className="text-brand-yellow">◇</span>
            <span className="section-title flex-1">UTXO Set</span>
            <span className="badge badge-yellow">{utxos.count} UTXOs</span>
            <span className="badge badge-green ml-2">{utxos.totalAmount?.toFixed(8)} {utxos.chain}</span>
          </div>
          {utxos.count === 0 ? (
            <div className="p-6 text-center text-gray-600 font-mono text-sm">No unspent UTXOs found</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>
                    <th className="table-head">TXID</th>
                    <th className="table-head">Vout</th>
                    <th className="table-head">Amount ↓</th>
                    <th className="table-head">Confs</th>
                    <th className="table-head">Status</th>
                    <th className="table-head">Source</th>
                  </tr>
                </thead>
                <tbody>
                  {utxos.utxos.map((u, i) => (
                    <tr key={i} className="hover:bg-dark-700/30">
                      <td className="table-cell"><span className="hash">{u.txid?.slice(0, 16)}…</span></td>
                      <td className="table-cell text-gray-500">{u.vout}</td>
                      <td className="table-cell text-brand-green font-bold text-sm">{u.amount?.toFixed(8)}</td>
                      <td className="table-cell text-brand-cyan">{u.confirmations}</td>
                      <td className="table-cell">
                        <span className={`badge ${u.spent ? 'badge-red' : 'badge-green'}`}>
                          {u.spent ? 'SPENT' : 'UNSPENT'}
                        </span>
                      </td>
                      <td className="table-cell">
                        <span className={`badge ${u.source === 'rpc' ? 'badge-purple' : 'badge-cyan'}`}>
                          {u.source?.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Fee Calculator ────────────────────────────────────────────────────────────
function FeeCalculator() {
  const [form, setForm] = useState({ inputCount: 2, outputCount: 2, feeRatePerByte: 10 });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [btcPrice, setBtcPrice] = useState(65000);

  const calculate = async () => {
    setLoading(true);
    try {
      const res = await axios.post('/api/admin/calculate-fee', form);
      setResult(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const usdFee = result ? result.totalFeeBTC * btcPrice : 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="card">
        <div className="card-header">
          <span className="text-brand-orange">⊘</span>
          <span className="section-title">BTC Fee Calculator</span>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="label">Number of Inputs</label>
            <input className="input" type="number" min={1} value={form.inputCount} onChange={e => setForm(p => ({ ...p, inputCount: parseInt(e.target.value) }))} />
            <p className="text-xs text-gray-600 font-mono mt-1">~148 bytes per input</p>
          </div>
          <div>
            <label className="label">Number of Outputs</label>
            <input className="input" type="number" min={1} value={form.outputCount} onChange={e => setForm(p => ({ ...p, outputCount: parseInt(e.target.value) }))} />
            <p className="text-xs text-gray-600 font-mono mt-1">~34 bytes per output</p>
          </div>
          <div>
            <label className="label">Fee Rate (sat/byte)</label>
            <input className="input" type="number" min={1} value={form.feeRatePerByte} onChange={e => setForm(p => ({ ...p, feeRatePerByte: parseInt(e.target.value) }))} />
            <div className="flex gap-2 mt-2">
              {[1, 5, 10, 25, 50, 100].map(r => (
                <button key={r} onClick={() => setForm(p => ({ ...p, feeRatePerByte: r }))}
                  className={`px-2 py-1 rounded text-xs font-mono border transition-all ${
                    form.feeRatePerByte === r
                      ? 'bg-brand-cyan/10 text-brand-cyan border-brand-cyan/30'
                      : 'text-gray-500 border-dark-400 hover:text-gray-300'
                  }`}>{r}</button>
              ))}
            </div>
          </div>
          <div>
            <label className="label">BTC Price (USD)</label>
            <input className="input" type="number" value={btcPrice} onChange={e => setBtcPrice(parseFloat(e.target.value))} />
          </div>
          <button onClick={calculate} disabled={loading} className="btn-primary w-full">
            {loading ? '⟳' : '⊘ Calculate Fee'}
          </button>
        </div>
      </div>

      {result && (
        <div className="card animate-fade-in">
          <div className="card-header">
            <span className="text-brand-yellow">≈</span>
            <span className="section-title">Fee Estimate</span>
          </div>
          <div className="p-5 space-y-4">
            <ResultRow label="Estimated Size" value={`${result.estimatedBytes} bytes`} />
            <ResultRow label="Fee Rate" value={`${result.feeRateSatPerByte} sat/byte`} />
            <div className="bg-dark-900 rounded-lg p-4 space-y-3 border border-dark-400">
              <div>
                <div className="text-xs text-gray-600 font-mono mb-1">Total Fee (Satoshis)</div>
                <div className="font-mono text-2xl text-brand-yellow">{result.totalFeeSatoshis.toLocaleString()} <span className="text-sm">sat</span></div>
              </div>
              <div>
                <div className="text-xs text-gray-600 font-mono mb-1">Total Fee (BTC)</div>
                <div className="font-mono text-xl text-brand-green">{result.totalFeeBTC.toFixed(8)} <span className="text-sm">BTC</span></div>
              </div>
              <div>
                <div className="text-xs text-gray-600 font-mono mb-1">Total Fee (USD)</div>
                <div className="font-mono text-lg text-brand-cyan">${usdFee.toFixed(4)}</div>
              </div>
            </div>
            <div className="text-xs text-gray-600 font-mono bg-dark-900 rounded p-3 border border-dark-400">
              Formula: ({form.inputCount} × 148) + ({form.outputCount} × 34) + 10 = {result.estimatedBytes} bytes<br />
              {result.estimatedBytes} × {result.feeRateSatPerByte} sat = {result.totalFeeSatoshis} satoshis
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ResultRow({ label, value }) {
  return (
    <div className="flex justify-between items-center py-2 border-b border-dark-500/50">
      <span className="text-xs text-gray-500 font-sans font-bold tracking-widest uppercase">{label}</span>
      <span className="font-mono text-sm text-gray-300">{value}</span>
    </div>
  );
}

// ── Raw TX Builder ─────────────────────────────────────────────────────────────
function RawTxBuilder() {
  const [chain, setChain] = useState('BTC');
  const [inputs, setInputs] = useState([{ txid: '', vout: 0, address: '', amount: '' }]);
  const [outputs, setOutputs] = useState([{ address: '', amount: '' }]);
  const [fee, setFee] = useState('0.0001');
  const [rawHex, setRawHex] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const addInput = () => setInputs(p => [...p, { txid: '', vout: 0, address: '', amount: '' }]);
  const addOutput = () => setOutputs(p => [...p, { address: '', amount: '' }]);
  const rmInput = (i) => setInputs(p => p.filter((_, idx) => idx !== i));
  const rmOutput = (i) => setOutputs(p => p.filter((_, idx) => idx !== i));

  const totalIn = inputs.reduce((s, x) => s + (parseFloat(x.amount) || 0), 0);
  const totalOut = outputs.reduce((s, x) => s + (parseFloat(x.amount) || 0), 0);
  const calcFee = totalIn - totalOut;

  const broadcast = async () => {
    setLoading(true);
    setResult(null);
    try {
      const res = await axios.post('/api/tx/broadcast', {
        chain,
        rawHex: rawHex || undefined,
        inputs,
        outputs,
        value: totalOut,
        fee: calcFee > 0 ? calcFee : parseFloat(fee),
        from: inputs[0]?.address,
        to: outputs[0]?.address,
      });
      setResult(res.data);
    } catch (err) {
      setResult({ error: err.response?.data?.error || 'Failed' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="card">
        <div className="card-header">
          <span className="text-brand-purple">⬒</span>
          <span className="section-title flex-1">Raw Transaction Builder</span>
          <select className="input w-24" value={chain} onChange={e => setChain(e.target.value)}>
            <option>BTC</option><option>ETH</option><option>BSC</option>
          </select>
        </div>
        <div className="p-5 space-y-5">
          {/* Inputs */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="label mb-0">Inputs</label>
              <button onClick={addInput} className="btn-ghost text-xs px-2 py-1">+ Add</button>
            </div>
            <div className="space-y-2">
              {inputs.map((inp, i) => (
                <div key={i} className="bg-dark-900 rounded p-3 border border-dark-400 grid grid-cols-4 gap-2">
                  <input className="input text-xs col-span-2" placeholder="TXID" value={inp.txid} onChange={e => setInputs(p => p.map((x, idx) => idx === i ? { ...x, txid: e.target.value } : x))} />
                  <input className="input text-xs" placeholder="Vout" type="number" value={inp.vout} onChange={e => setInputs(p => p.map((x, idx) => idx === i ? { ...x, vout: e.target.value } : x))} />
                  <div className="flex gap-1">
                    <input className="input text-xs flex-1" placeholder="Amount" type="number" value={inp.amount} onChange={e => setInputs(p => p.map((x, idx) => idx === i ? { ...x, amount: e.target.value } : x))} />
                    {inputs.length > 1 && <button onClick={() => rmInput(i)} className="text-brand-red text-xs px-2">✕</button>}
                  </div>
                  <input className="input text-xs col-span-4" placeholder="Address" value={inp.address} onChange={e => setInputs(p => p.map((x, idx) => idx === i ? { ...x, address: e.target.value } : x))} />
                </div>
              ))}
            </div>
          </div>

          {/* Outputs */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="label mb-0">Outputs</label>
              <button onClick={addOutput} className="btn-ghost text-xs px-2 py-1">+ Add</button>
            </div>
            <div className="space-y-2">
              {outputs.map((out, i) => (
                <div key={i} className="bg-dark-900 rounded p-3 border border-dark-400 flex gap-2">
                  <input className="input text-xs flex-1" placeholder="Address" value={out.address} onChange={e => setOutputs(p => p.map((x, idx) => idx === i ? { ...x, address: e.target.value } : x))} />
                  <input className="input text-xs w-36" placeholder="Amount" type="number" value={out.amount} onChange={e => setOutputs(p => p.map((x, idx) => idx === i ? { ...x, amount: e.target.value } : x))} />
                  {outputs.length > 1 && <button onClick={() => rmOutput(i)} className="text-brand-red text-xs px-2">✕</button>}
                </div>
              ))}
            </div>
          </div>

          {/* Summary */}
          <div className="bg-dark-900 rounded-lg p-4 border border-dark-400 grid grid-cols-3 gap-4 font-mono text-xs">
            <div><div className="text-gray-600 mb-1">Total In</div><div className="text-brand-green">{totalIn.toFixed(8)}</div></div>
            <div><div className="text-gray-600 mb-1">Total Out</div><div className="text-brand-cyan">{totalOut.toFixed(8)}</div></div>
            <div><div className="text-gray-600 mb-1">Implied Fee</div><div className={calcFee >= 0 ? 'text-brand-yellow' : 'text-brand-red'}>{calcFee.toFixed(8)}</div></div>
          </div>

          {/* Optional raw hex */}
          <div>
            <label className="label">Raw Hex (optional)</label>
            <input className="input font-mono text-xs" placeholder="020000000… (paste raw hex)" value={rawHex} onChange={e => setRawHex(e.target.value)} />
          </div>

          <button onClick={broadcast} disabled={loading} className="btn-purple w-full py-3">
            {loading ? '⟳ Broadcasting…' : '↑ Broadcast to Internal Mempool'}
          </button>

          {result && (
            <div className={`px-4 py-3 rounded border font-mono text-xs ${
              result.error ? 'bg-brand-red/10 border-brand-red/30 text-brand-red' : 'bg-brand-green/10 border-brand-green/30 text-brand-green'
            }`}>
              {result.error ? `✗ ${result.error}` : `✓ ${result.txid}`}
              {!result.error && <div className="text-gray-500 mt-1">{result.message}</div>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Mempool View ───────────────────────────────────────────────────────────────
function MempoolView() {
  const [mempool, setMempool] = useState([]);
  const [loading, setLoading] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(false);

  const fetchMempool = async () => {
    setLoading(true);
    try {
      const res = await axios.get('/api/tx/mempool/list');
      setMempool(res.data.transactions || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useState(() => { fetchMempool(); }, []);

  return (
    <div className="card">
      <div className="card-header">
        <span className="text-brand-yellow animate-pulse">◉</span>
        <span className="section-title flex-1">Mempool — Real-time View</span>
        <button onClick={fetchMempool} disabled={loading} className="btn-ghost text-xs px-3 py-1 mr-2">
          {loading ? '⟳' : '↺ Refresh'}
        </button>
        <span className="badge badge-yellow">{mempool.length} PENDING</span>
      </div>

      {mempool.length === 0 ? (
        <div className="p-8 text-center text-gray-600 font-mono text-sm">
          Mempool is empty. <br />
          <button onClick={fetchMempool} className="text-brand-cyan mt-2 hover:underline">Refresh</button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr>
                <th className="table-head">TXID</th>
                <th className="table-head">Chain</th>
                <th className="table-head">From</th>
                <th className="table-head">To</th>
                <th className="table-head">Value</th>
                <th className="table-head">Fee</th>
                <th className="table-head">Size</th>
                <th className="table-head">Received</th>
              </tr>
            </thead>
            <tbody>
              {mempool.map(tx => (
                <tr key={tx._id} className="hover:bg-dark-700/30">
                  <td className="table-cell"><span className="hash">{tx.txid?.slice(0, 16)}…</span></td>
                  <td className="table-cell">
                    <span className={`badge ${tx.chain === 'BTC' ? 'badge-orange' : tx.chain === 'ETH' ? 'badge-purple' : 'badge-yellow'}`}>
                      {tx.chain}
                    </span>
                  </td>
                  <td className="table-cell"><span className="addr">{tx.from ? tx.from.slice(0, 12) + '…' : '—'}</span></td>
                  <td className="table-cell"><span className="addr">{tx.to ? tx.to.slice(0, 12) + '…' : '—'}</span></td>
                  <td className="table-cell text-brand-green">{(tx.value || 0).toFixed(6)}</td>
                  <td className="table-cell text-brand-yellow">{(tx.fee || 0).toFixed(8)}</td>
                  <td className="table-cell text-gray-500">{tx.size || '—'}</td>
                  <td className="table-cell text-gray-500 text-xs">
                    {tx.timestamp ? new Date(tx.timestamp).toLocaleTimeString() : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
