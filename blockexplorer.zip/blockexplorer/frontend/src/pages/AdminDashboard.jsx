import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { useWS } from '../contexts/WSContext';

const fmtDate = ts => ts ? new Date(ts).toLocaleString() : '—';
const shortHash = h => h ? h.slice(0, 10) + '…' + h.slice(-6) : '—';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [actionMsg, setActionMsg] = useState('');
  const [addresses, setAddresses] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const { lastMessage } = useWS();

  const fetchStats = useCallback(async () => {
    try {
      const res = await axios.get('/api/admin/stats');
      setStats(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchAddresses = useCallback(async (p = 1) => {
    try {
      const res = await axios.get(`/api/admin/addresses?page=${p}&limit=15`);
      setAddresses(res.data.addresses || []);
      setTotalPages(Math.ceil(res.data.total / 15));
    } catch (err) { console.error(err); }
  }, []);

  const fetchTransactions = useCallback(async (p = 1) => {
    try {
      const res = await axios.get(`/api/admin/transactions?page=${p}&limit=15`);
      setTransactions(res.data.transactions || []);
      setTotalPages(Math.ceil(res.data.total / 15));
    } catch (err) { console.error(err); }
  }, []);

  useEffect(() => { fetchStats(); }, [fetchStats]);

  useEffect(() => {
    if (lastMessage?.type === 'NEW_BLOCK' || lastMessage?.type === 'NEW_TX') {
      fetchStats();
    }
  }, [lastMessage, fetchStats]);

  useEffect(() => {
    if (activeTab === 'addresses') fetchAddresses(page);
    if (activeTab === 'transactions') fetchTransactions(page);
  }, [activeTab, page, fetchAddresses, fetchTransactions]);

  const doAction = async (action, label) => {
    if (!window.confirm(`Are you sure you want to: ${label}?`)) return;
    try {
      const res = await axios.post(`/api/admin/${action}`);
      setActionMsg(`✓ ${res.data.message || label + ' completed'}`);
      fetchStats();
    } catch (err) {
      setActionMsg(`✗ ${err.response?.data?.error || 'Action failed'}`);
    }
    setTimeout(() => setActionMsg(''), 5000);
  };

  const deleteAddress = async (id) => {
    try {
      await axios.delete(`/api/address/${id}`);
      fetchAddresses(page);
    } catch (err) { console.error(err); }
  };

  const deleteTx = async (id) => {
    try {
      await axios.delete(`/api/tx/${id}`);
      fetchTransactions(page);
      fetchStats();
    } catch (err) { console.error(err); }
  };

  const tabs = [
    { id: 'overview', label: '⬡ Overview' },
    { id: 'addresses', label: '◎ Addresses' },
    { id: 'transactions', label: '⇄ Transactions' },
    { id: 'actions', label: '⚙ Actions' },
  ];

  return (
    <div className="p-6 animate-fade-in">
      <div className="mb-6 flex items-start justify-between">
        <div>
          <h1 className="font-sans font-bold text-xl text-gray-100">Admin Dashboard</h1>
          <p className="text-xs text-gray-500 font-mono mt-0.5">Full control over the internal blockchain database</p>
        </div>
        <span className="badge badge-cyan">admin</span>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 bg-dark-800 rounded-lg p-1 border border-dark-500">
        {tabs.map(t => (
          <button key={t.id} onClick={() => { setActiveTab(t.id); setPage(1); }}
            className={`px-4 py-2 rounded text-xs font-bold tracking-wider font-sans uppercase transition-all
              ${activeTab === t.id
                ? 'bg-brand-cyan/10 text-brand-cyan border border-brand-cyan/30'
                : 'text-gray-500 hover:text-gray-300 border border-transparent'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {actionMsg && (
        <div className={`mb-4 px-4 py-2 rounded font-mono text-xs border ${
          actionMsg.startsWith('✓') ? 'bg-brand-green/10 border-brand-green/30 text-brand-green' : 'bg-brand-red/10 border-brand-red/30 text-brand-red'
        }`}>{actionMsg}</div>
      )}

      {/* Overview */}
      {activeTab === 'overview' && stats && (
        <div className="space-y-6 animate-fade-in">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              { label: 'Addresses', value: stats.stats.addresses, color: 'text-brand-cyan' },
              { label: 'Transactions', value: stats.stats.transactions, color: 'text-brand-green' },
              { label: 'UTXOs', value: stats.stats.utxos, color: 'text-brand-yellow' },
              { label: 'Blocks', value: stats.stats.blocks, color: 'text-brand-purple' },
              { label: 'Pending', value: stats.stats.pending, color: 'text-brand-orange' },
              { label: 'Confirmed', value: stats.stats.confirmed, color: 'text-brand-green' },
            ].map(s => (
              <div key={s.label} className="card p-4">
                <div className="label">{s.label}</div>
                <div className={`font-mono text-2xl font-bold ${s.color}`}>{s.value}</div>
              </div>
            ))}
          </div>

          {/* Recent Blocks */}
          <div className="card">
            <div className="card-header">
              <span className="text-brand-cyan">⬡</span>
              <span className="section-title flex-1">Recent Blocks</span>
              {stats.latestBlock && <span className="badge badge-green">Latest #{stats.latestBlock.height}</span>}
            </div>
            {!stats.recentBlocks?.length ? (
              <div className="p-6 text-center text-gray-600 font-mono text-sm">No blocks yet. Mine the first block from the Home page.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead><tr>
                    <th className="table-head">Height</th>
                    <th className="table-head">Hash</th>
                    <th className="table-head">Txs</th>
                    <th className="table-head">Fees</th>
                    <th className="table-head">Miner</th>
                    <th className="table-head">Time</th>
                  </tr></thead>
                  <tbody>
                    {stats.recentBlocks.map(b => (
                      <tr key={b._id} className="hover:bg-dark-700/30">
                        <td className="table-cell text-brand-cyan font-bold">#{b.height}</td>
                        <td className="table-cell"><span className="hash">{shortHash(b.hash)}</span></td>
                        <td className="table-cell text-brand-green">{b.txCount}</td>
                        <td className="table-cell text-brand-yellow">{b.totalFees?.toFixed(6)}</td>
                        <td className="table-cell text-gray-400">{b.miner}</td>
                        <td className="table-cell text-gray-500 text-xs">{fmtDate(b.timestamp)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Recent Txs */}
          <div className="card">
            <div className="card-header">
              <span className="text-brand-yellow">⇄</span>
              <span className="section-title">Recent Transactions</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead><tr>
                  <th className="table-head">TXID</th>
                  <th className="table-head">Chain</th>
                  <th className="table-head">Status</th>
                  <th className="table-head">Value</th>
                  <th className="table-head">Confs</th>
                  <th className="table-head">Source</th>
                  <th className="table-head">Time</th>
                </tr></thead>
                <tbody>
                  {stats.recentTxs?.map(tx => (
                    <tr key={tx._id} className="hover:bg-dark-700/30">
                      <td className="table-cell"><span className="hash">{shortHash(tx.txid)}</span></td>
                      <td className="table-cell">
                        <span className={`badge ${tx.chain === 'BTC' ? 'badge-orange' : tx.chain === 'ETH' ? 'badge-purple' : 'badge-yellow'}`}>{tx.chain}</span>
                      </td>
                      <td className="table-cell">
                        <span className={`badge ${tx.status === 'confirmed' ? 'badge-green' : tx.status === 'pending' ? 'badge-yellow' : 'badge-red'}`}>
                          {tx.status?.toUpperCase()}
                        </span>
                      </td>
                      <td className="table-cell text-brand-green">{tx.value?.toFixed(6)}</td>
                      <td className="table-cell text-brand-cyan">{tx.confirmations}</td>
                      <td className="table-cell"><span className={`badge ${tx.source === 'rpc' ? 'badge-purple' : 'badge-cyan'}`}>{tx.source}</span></td>
                      <td className="table-cell text-gray-500 text-xs">{fmtDate(tx.timestamp)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Addresses */}
      {activeTab === 'addresses' && (
        <div className="card animate-fade-in">
          <div className="card-header">
            <span className="text-brand-green">◎</span>
            <span className="section-title">Stored Addresses</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead><tr>
                <th className="table-head">Address</th>
                <th className="table-head">Chain</th>
                <th className="table-head">Balance</th>
                <th className="table-head">Tx Count</th>
                <th className="table-head">Source</th>
                <th className="table-head">Notes</th>
                <th className="table-head">Created</th>
                <th className="table-head"></th>
              </tr></thead>
              <tbody>
                {addresses.map(a => (
                  <tr key={a._id} className="hover:bg-dark-700/30">
                    <td className="table-cell"><span className="addr">{a.address?.slice(0, 20)}…</span></td>
                    <td className="table-cell"><span className={`badge ${a.chain === 'BTC' ? 'badge-orange' : 'badge-purple'}`}>{a.chain}</span></td>
                    <td className="table-cell text-brand-green">{a.balance?.toFixed(8)}</td>
                    <td className="table-cell">{a.txCount}</td>
                    <td className="table-cell"><span className={`badge ${a.source === 'rpc' ? 'badge-purple' : 'badge-cyan'}`}>{a.source}</span></td>
                    <td className="table-cell text-gray-500 text-xs">{a.notes || '—'}</td>
                    <td className="table-cell text-gray-500 text-xs">{fmtDate(a.createdAt)}</td>
                    <td className="table-cell">
                      <button onClick={() => deleteAddress(a._id)} className="text-brand-red text-xs hover:text-red-400">✕</button>
                    </td>
                  </tr>
                ))}
                {addresses.length === 0 && (
                  <tr><td colSpan={8} className="table-cell text-center text-gray-600 py-8">No addresses stored</td></tr>
                )}
              </tbody>
            </table>
          </div>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </div>
      )}

      {/* Transactions */}
      {activeTab === 'transactions' && (
        <div className="card animate-fade-in">
          <div className="card-header">
            <span className="text-brand-cyan">⇄</span>
            <span className="section-title">All Transactions</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead><tr>
                <th className="table-head">TXID</th>
                <th className="table-head">Chain</th>
                <th className="table-head">Status</th>
                <th className="table-head">Value</th>
                <th className="table-head">Fee</th>
                <th className="table-head">Confs</th>
                <th className="table-head">Block</th>
                <th className="table-head">Source</th>
                <th className="table-head">Time</th>
                <th className="table-head"></th>
              </tr></thead>
              <tbody>
                {transactions.map(tx => (
                  <tr key={tx._id} className="hover:bg-dark-700/30">
                    <td className="table-cell"><span className="hash">{shortHash(tx.txid)}</span></td>
                    <td className="table-cell"><span className={`badge ${tx.chain === 'BTC' ? 'badge-orange' : 'badge-purple'}`}>{tx.chain}</span></td>
                    <td className="table-cell">
                      <span className={`badge ${tx.status === 'confirmed' ? 'badge-green' : tx.status === 'pending' ? 'badge-yellow' : 'badge-red'}`}>
                        {tx.status?.toUpperCase()}
                      </span>
                    </td>
                    <td className="table-cell text-brand-green">{tx.value?.toFixed(6)}</td>
                    <td className="table-cell text-brand-yellow">{tx.fee?.toFixed(8)}</td>
                    <td className="table-cell text-brand-cyan">{tx.confirmations}</td>
                    <td className="table-cell text-gray-500">{tx.blockHeight ? `#${tx.blockHeight}` : '—'}</td>
                    <td className="table-cell"><span className={`badge ${tx.source === 'rpc' ? 'badge-purple' : tx.source === 'broadcast' ? 'badge-orange' : 'badge-cyan'}`}>{tx.source}</span></td>
                    <td className="table-cell text-gray-500 text-xs">{fmtDate(tx.timestamp)}</td>
                    <td className="table-cell">
                      <button onClick={() => deleteTx(tx._id)} className="text-brand-red text-xs hover:text-red-400">✕</button>
                    </td>
                  </tr>
                ))}
                {transactions.length === 0 && (
                  <tr><td colSpan={10} className="table-cell text-center text-gray-600 py-8">No transactions found</td></tr>
                )}
              </tbody>
            </table>
          </div>
          <Pagination page={page} totalPages={totalPages} setPage={setPage} />
        </div>
      )}

      {/* Actions */}
      {activeTab === 'actions' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 animate-fade-in">
          <div className="card">
            <div className="card-header">
              <span className="text-brand-yellow">⚙</span>
              <span className="section-title">Database Actions</span>
            </div>
            <div className="p-5 space-y-3">
              <ActionBtn
                label="Clear Mempool"
                desc="Delete all pending transactions"
                color="yellow"
                onClick={() => doAction('clear-mempool', 'Clear Mempool')}
              />
              <ActionBtn
                label="Reset All Data"
                desc="Wipe all addresses, transactions, UTXOs, and blocks"
                color="red"
                onClick={() => doAction('reset-all', 'Reset All Data')}
              />
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <span className="text-brand-cyan">⬡</span>
              <span className="section-title">Quick Mine</span>
            </div>
            <div className="p-5">
              <p className="text-xs text-gray-500 font-mono mb-4">
                Collect all pending transactions and mine them into a new block.
                This increases confirmations and moves txs from mempool to confirmed state.
              </p>
              <MineButton />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ActionBtn({ label, desc, color, onClick }) {
  const colors = {
    red: 'btn-danger',
    yellow: 'btn text-brand-yellow bg-brand-yellow/10 border-brand-yellow/30 hover:bg-brand-yellow/20',
    cyan: 'btn-primary',
  };
  return (
    <div className="bg-dark-900 rounded p-4 border border-dark-400 flex items-center justify-between">
      <div>
        <div className="font-sans font-bold text-sm text-gray-200">{label}</div>
        <div className="text-xs text-gray-500 font-mono mt-0.5">{desc}</div>
      </div>
      <button onClick={onClick} className={`${colors[color]} shrink-0`}>{label}</button>
    </div>
  );
}

function MineButton() {
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  const mine = async () => {
    setLoading(true);
    setMsg('');
    try {
      const res = await axios.post('/api/blocks/mine', { miner: 'Admin Dashboard' });
      setMsg(`✓ ${res.data.message}`);
    } catch (err) {
      setMsg(`✗ ${err.response?.data?.error || 'Failed'}`);
    } finally {
      setLoading(false);
      setTimeout(() => setMsg(''), 5000);
    }
  };

  return (
    <>
      <button onClick={mine} disabled={loading} className="btn-success w-full py-3 flex items-center justify-center gap-2">
        <span>⛏</span>
        {loading ? 'Mining…' : 'Mine New Block'}
      </button>
      {msg && (
        <div className={`mt-3 px-3 py-2 rounded font-mono text-xs border ${
          msg.startsWith('✓') ? 'bg-brand-green/10 border-brand-green/30 text-brand-green' : 'bg-brand-red/10 border-brand-red/30 text-brand-red'
        }`}>{msg}</div>
      )}
    </>
  );
}

function Pagination({ page, totalPages, setPage }) {
  if (totalPages <= 1) return null;
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-dark-500">
      <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="btn-ghost text-xs px-3 py-1 disabled:opacity-30">← Prev</button>
      <span className="font-mono text-xs text-gray-500">Page {page} / {totalPages}</span>
      <button disabled={page === totalPages} onClick={() => setPage(p => p + 1)} className="btn-ghost text-xs px-3 py-1 disabled:opacity-30">Next →</button>
    </div>
  );
}
