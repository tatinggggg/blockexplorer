import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(form.username, form.password);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.error || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-900 flex items-center justify-center p-4"
      style={{ background: 'radial-gradient(ellipse 800px 600px at 50% 40%, rgba(0,212,255,.05) 0%, #050810 70%)' }}>

      <div className="w-full max-w-sm animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="text-4xl mb-2">⬡</div>
          <div className="font-mono text-brand-cyan text-xl tracking-[6px] glow-cyan">
            BLOCKXPLORER
          </div>
          <div className="text-xs text-gray-600 font-mono tracking-widest mt-1">
            DEVELOPER TOOLS v1.0
          </div>
        </div>

        {/* Card */}
        <div className="card">
          <div className="card-header">
            <span className="text-xs font-mono text-brand-cyan">⬒</span>
            <span className="section-title text-gray-300">Admin Access</span>
          </div>
          <div className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Username</label>
                <input
                  className="input"
                  type="text"
                  autoComplete="username"
                  placeholder="admin"
                  value={form.username}
                  onChange={e => setForm(p => ({ ...p, username: e.target.value }))}
                  required
                />
              </div>
              <div>
                <label className="label">Password</label>
                <input
                  className="input"
                  type="password"
                  autoComplete="current-password"
                  placeholder="••••••••••"
                  value={form.password}
                  onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                  required
                />
              </div>

              {error && (
                <div className="text-xs text-brand-red font-mono bg-brand-red/10 border border-brand-red/30 rounded px-3 py-2">
                  ✗ {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full btn-primary py-3 text-sm"
              >
                {loading ? '⟳ Authenticating…' : '→ Login'}
              </button>
            </form>

            <div className="mt-4 pt-4 border-t border-dark-500 text-center">
              <span className="text-xs text-gray-600 font-mono">
                Secure admin access only. No registration.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
