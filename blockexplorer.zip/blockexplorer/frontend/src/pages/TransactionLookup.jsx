import { useState } from 'react';
import axios from 'axios';

const shortHash = h => h ? h.slice(0, 12) + '…' + h.slice(-6) : '—';
const fmtDate = ts => ts ? new Date(ts).toLocaleString() : '—';

export default function TransactionLookup() {
  const [chain, setChain] = useState('BTC');
  const [txid, setTxid] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Broadcast form
  const [bcForm, setBcForm] = useState({
    chain: 'BTC',
    rawHex: '',
    from: '',
    to: '',
    value: '',
    fee: '',
    inputs: '[]',
    outputs: '[]',
  });
  const [bcResult, setBcResult] = useState(null);
  const [bcLoading, setBcLoading] = useState(false);
  const [bcError, setBcError] = useState('');

  const lookup = async (e) => {
    e.preventDefault();
    if (!txid.trim()) return;
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const res = await axios.get(`/api/tx/${chain}/${txid.trim()}`);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.error || err.response?.data?.detail || 'Lookup failed');
    } finally {
      setLoading(false);
    }
  };

  const broadcast = async (e) => {
    e.preventDefault();
    setBcLoading(true);
    setBcError('');
    setBcResult(null);
    try {
      let inputs = [], outputs = [];
      try { inputs = JSON.parse(bcForm.inputs); } catch (_) {}
      try { outputs = JSON.parse(bcForm.outputs); } catch (_) {}

      const res = await axios.post('/api/tx/broadcast', {
        chain: bcForm.chain,
        rawHex: bcForm.rawHex || undefined,
        from: bcForm.from || undefined,
        to: bcForm.to || undefined,
        value: bcForm.value ? parseFloat(bcForm.value) : undefined,
        fee: bcForm.fee ? parseFloat(bcForm.fee) : 0,
        inputs,
        outputs,
      });
      setBcResult(res.data);
    } catch (err) {
      setBcError(err.response?.data?.error || 'Broadcast failed');
    } finally {
      setBcLoading(false);
    }
  };

  return (
    <div className="p-6 animate-fade-in">
      <div className="mb-6">
        <h1 className="font-sans font-bold text-xl text-gray-100">Transaction Lookup</h1>
        <p className="text-xs text-gray-500 font-mono mt-0.5">
          Hybrid lookup: MongoDB first → public RPC fallback. Broadcast = internal only.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Lookup */}
        <div>
          <div className="card mb-4">
            <div className="card-header">
              <span className="text-brand-cyan">⇄</span>
              <span className="section-title">Transaction Lookup</span>
            </div>
            <form onSubmit={lookup} className="p-5">
              <div className="flex gap-3 mb-3">
                <select className="input w-28 shrink-0" value={chain} onChange={e => setChain(e.target.value)}>
                  <option>BTC</option>
                  <option>ETH</option>
                  <option>BSC</option>
                </select>
                <input
                  className="input flex-1"
                  placeholder="Transaction ID / Hash…"
                  value={txid}
                  onChange={e => setTxid(e.target.value)}
                />
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full">
                {loading ? '⟳ Searching…' : '→ Lookup Transaction'}
              </button>
            </form>
          </div>

          {error && (
            <div className="mb-4 px-4 py-3 bg-brand-red/10 border border-brand-red/30 rounded text-brand-red font-mono text-sm">
              ✗ {error}
            </div>
          )}

          {result && (
            <div className="card animate-fade-in">
              <div className="card-header">
                <span className="text-brand-cyan">⇄</span>
                <span className="section-title flex-1">Transaction Details</span>
                <span className={`badge ${result.source === 'db' ? 'badge-green' : 'badge-purple'}`}>
                  {result.source === 'db' ? 'MongoDB' : 'RPC'}
                </span>
              </div>
              <div className="p-5 space-y-0">
                <InfoRow label="TXID" value={result.data.txid} mono small />
                <InfoRow label="Chain" value={result.data.chain} />
                <InfoRow label="Status">
                  <span className={`badge ${
                    result.data.status === 'confirmed' ? 'badge-green' :
                    result.data.status === 'pending' ? 'badge-yellow' : 'badge-red'
                  }`}>{result.data.status?.toUpperCase()}</span>
                </InfoRow>
                <InfoRow label="Confirmations" value={result.data.confirmations} highlight="cyan" />
                <InfoRow label="Block" value={result.data.blockHeight ? `#${result.data.blockHeight}` : '—'} />
                <InfoRow label="Value" value={`${result.data.value?.toFixed(8) || '0'} ${result.data.chain}`} highlight="green" />
                <InfoRow label="Fee" value={`${result.data.fee?.toFixed(8) || '0'}`} />
                <InfoRow label="Size" value={result.data.size ? `${result.data.size} bytes` : '—'} />
                {result.data.from && <InfoRow label="From" value={result.data.from} mono small />}
                {result.data.to && <InfoRow label="To" value={result.data.to} mono small />}
                <InfoRow label="Timestamp" value={fmtDate(result.data.timestamp)} />
                <InfoRow label="Source" value={result.data.source} />
              </div>

              {/* Inputs */}
              {result.data.inputs?.length > 0 && (
                <div className="px-5 pb-3">
                  <div className="label mt-3">Inputs ({result.data.inputs.length})</div>
                  <div className="space-y-1">
                    {result.data.inputs.map((inp, i) => (
                      <div key={i} className="bg-dark-900 rounded p-2.5 font-mono text-xs flex gap-3">
                        <span className="text-gray-600">#{i}</span>
                        <span className="text-brand-green flex-1">{inp.address || '—'}</span>
                        <span className="text-brand-yellow">{inp.amount?.toFixed(8)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Outputs */}
              {result.data.outputs?.length > 0 && (
                <div className="px-5 pb-5">
                  <div className="label mt-3">Outputs ({result.data.outputs.length})</div>
                  <div className="space-y-1">
                    {result.data.outputs.map((out, i) => (
                      <div key={i} className="bg-dark-900 rounded p-2.5 font-mono text-xs flex gap-3">
                        <span className="text-gray-600">#{out.n ?? i}</span>
                        <span className="text-brand-green flex-1">{out.address || '—'}</span>
                        <span className="text-brand-yellow">{out.amount?.toFixed(8)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Broadcast */}
        <div>
          <div className="card">
            <div className="card-header">
              <span className="text-brand-purple">↑</span>
              <span className="section-title flex-1">Broadcast Transaction</span>
              <span className="badge badge-purple">INTERNAL ONLY</span>
            </div>
            <form onSubmit={broadcast} className="p-5 space-y-4">
              <div className="bg-brand-yellow/5 border border-brand-yellow/20 rounded px-3 py-2">
                <p className="text-xs text-brand-yellow font-mono">
                  ⚠ Does NOT send to real blockchain. Accepts unsigned transactions.
                  Skips signature verification. Generates TXID via SHA256.
                </p>
              </div>

              <div>
                <label className="label">Chain</label>
                <select className="input" value={bcForm.chain} onChange={e => setBcForm(p => ({ ...p, chain: e.target.value }))}>
                  <option>BTC</option>
                  <option>ETH</option>
                  <option>BSC</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">From Address</label>
                  <input className="input" placeholder="Sender address" value={bcForm.from} onChange={e => setBcForm(p => ({ ...p, from: e.target.value }))} />
                </div>
                <div>
                  <label className="label">To Address</label>
                  <input className="input" placeholder="Recipient address" value={bcForm.to} onChange={e => setBcForm(p => ({ ...p, to: e.target.value }))} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Value</label>
                  <input className="input" type="number" step="0.00000001" placeholder="0.00000000" value={bcForm.value} onChange={e => setBcForm(p => ({ ...p, value: e.target.value }))} />
                </div>
                <div>
                  <label className="label">Fee</label>
                  <input className="input" type="number" step="0.00000001" placeholder="0.00000000" value={bcForm.fee} onChange={e => setBcForm(p => ({ ...p, fee: e.target.value }))} />
                </div>
              </div>

              <div>
                <label className="label">Raw Hex (optional)</label>
                <input className="input font-mono text-xs" placeholder="020000000..." value={bcForm.rawHex} onChange={e => setBcForm(p => ({ ...p, rawHex: e.target.value }))} />
              </div>

              <div>
                <label className="label">Inputs JSON (optional)</label>
                <textarea
                  className="input text-xs h-20 resize-none"
                  placeholder='[{"address":"1A…","amount":0.5,"txid":"abc…","vout":0}]'
                  value={bcForm.inputs}
                  onChange={e => setBcForm(p => ({ ...p, inputs: e.target.value }))}
                />
              </div>

              <div>
                <label className="label">Outputs JSON (optional)</label>
                <textarea
                  className="input text-xs h-20 resize-none"
                  placeholder='[{"address":"1B…","amount":0.49}]'
                  value={bcForm.outputs}
                  onChange={e => setBcForm(p => ({ ...p, outputs: e.target.value }))}
                />
              </div>

              {bcError && (
                <div className="px-3 py-2 bg-brand-red/10 border border-brand-red/30 rounded text-brand-red font-mono text-xs">
                  ✗ {bcError}
                </div>
              )}

              <button type="submit" disabled={bcLoading} className="btn-purple w-full py-3">
                {bcLoading ? '⟳ Broadcasting…' : '↑ Broadcast to Internal Mempool'}
              </button>
            </form>

            {bcResult && (
              <div className="mx-5 mb-5 p-4 bg-brand-green/10 border border-brand-green/30 rounded animate-fade-in">
                <div className="text-brand-green font-mono text-sm font-bold mb-2">✓ Accepted</div>
                <div className="font-mono text-xs text-gray-400 space-y-1">
                  <div><span className="text-gray-600">TXID: </span><span className="text-brand-cyan">{bcResult.txid}</span></div>
                  <div><span className="text-gray-600">Status: </span><span className="text-brand-yellow">{bcResult.status}</span></div>
                  <div className="text-gray-600 text-xs mt-2">{bcResult.message}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ label, value, mono, small, highlight, children }) {
  const colors = { green: 'text-brand-green', cyan: 'text-brand-cyan', yellow: 'text-brand-yellow' };
  return (
    <div className="flex items-start gap-4 py-2 border-b border-dark-500/50 last:border-0">
      <span className="text-xs font-bold tracking-widest uppercase text-gray-500 font-sans w-32 shrink-0 pt-0.5">{label}</span>
      {children || (
        <span className={`font-mono ${small ? 'text-xs' : 'text-sm'} break-all ${highlight ? colors[highlight] : 'text-gray-300'}`}>
          {value}
        </span>
      )}
    </div>
  );
}
