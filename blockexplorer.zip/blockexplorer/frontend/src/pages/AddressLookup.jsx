import { useState } from 'react';
import axios from 'axios';

const shortHash = h => h ? h.slice(0, 12) + '…' + h.slice(-6) : '—';
const fmtDate = ts => ts ? new Date(ts).toLocaleString() : '—';

export default function AddressLookup() {
  const [chain, setChain] = useState('BTC');
  const [address, setAddress] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('info');

  const lookup = async (e) => {
    e.preventDefault();
    if (!address.trim()) return;
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const res = await axios.get(`/api/address/${chain}/${address.trim()}`);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.error || err.response?.data?.detail || 'Lookup failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 animate-fade-in">
      <div className="mb-6">
        <h1 className="font-sans font-bold text-xl text-gray-100">Address Lookup</h1>
        <p className="text-xs text-gray-500 font-mono mt-0.5">
          Step 1: Check MongoDB → Step 2: Fallback to public RPC
        </p>
      </div>

      {/* Search */}
      <div className="card mb-6">
        <div className="card-header">
          <span className="text-brand-green">◎</span>
          <span className="section-title">Search Address</span>
        </div>
        <form onSubmit={lookup} className="p-5">
          <div className="flex gap-3">
            <select
              className="input w-28 shrink-0"
              value={chain}
              onChange={e => setChain(e.target.value)}
            >
              <option value="BTC">BTC</option>
              <option value="ETH">ETH</option>
              <option value="BSC">BSC</option>
            </select>
            <input
              className="input flex-1"
              placeholder={chain === 'BTC' ? '1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf…' : '0x742d35Cc6634C053…'}
              value={address}
              onChange={e => setAddress(e.target.value)}
            />
            <button type="submit" disabled={loading} className="btn-primary px-6 shrink-0">
              {loading ? '⟳' : '→ Lookup'}
            </button>
          </div>
          {/* Hybrid indicator */}
          <div className="flex gap-4 mt-3 text-xs font-mono text-gray-600">
            <span className="text-brand-cyan">① MongoDB check</span>
            <span>→</span>
            <span className="text-brand-purple">② RPC fallback</span>
            <span>→</span>
            <span className="text-brand-green">③ Cache & return</span>
          </div>
        </form>
      </div>

      {error && (
        <div className="mb-4 px-4 py-3 bg-brand-red/10 border border-brand-red/30 rounded text-brand-red font-mono text-sm">
          ✗ {error}
        </div>
      )}

      {result && (
        <div className="animate-fade-in">
          {/* Source badge */}
          <div className="flex items-center gap-3 mb-4">
            <span className={`badge ${result.source === 'db' ? 'badge-green' : 'badge-purple'}`}>
              {result.source === 'db' ? '✓ From MongoDB' : '⟳ From Public RPC'}
            </span>
            <span className="text-xs text-gray-600 font-mono">
              {result.source === 'db' ? 'Found in internal database' : 'Fetched & cached from blockchain'}
            </span>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 mb-4">
            {['info', 'utxos', 'txs'].map(t => (
              <button
                key={t}
                onClick={() => setActiveTab(t)}
                className={`px-4 py-1.5 rounded text-xs font-bold tracking-widest uppercase font-sans border transition-all
                  ${activeTab === t
                    ? 'bg-brand-cyan/10 text-brand-cyan border-brand-cyan/30'
                    : 'text-gray-500 border-transparent hover:text-gray-300'}`}
              >
                {t === 'info' ? 'Info' : t === 'utxos' ? `UTXOs (${result.data?.utxos?.length || 0})` : `Txs (${result.data?.recentTxs?.length || 0})`}
              </button>
            ))}
          </div>

          {/* Info */}
          {activeTab === 'info' && (
            <div className="card">
              <div className="card-header">
                <span className="text-brand-green">◎</span>
                <span className="section-title">Address Details</span>
                <span className={`badge ml-auto ${chain === 'BTC' ? 'badge-orange' : chain === 'ETH' ? 'badge-purple' : 'badge-yellow'}`}>{chain}</span>
              </div>
              <div className="p-5">
                <InfoRow label="Address" value={result.data.address} mono />
                <InfoRow label="Chain" value={result.data.chain} />
                <InfoRow label="Balance" value={`${result.data.balance?.toFixed(8) || '0'} ${chain}`} highlight="green" />
                <InfoRow label="Total Received" value={`${result.data.totalReceived?.toFixed(8) || '0'} ${chain}`} />
                <InfoRow label="Total Sent" value={`${result.data.totalSent?.toFixed(8) || '0'} ${chain}`} />
                <InfoRow label="Tx Count" value={result.data.txCount || '0'} />
                <InfoRow label="Notes" value={result.data.notes || '—'} />
                <InfoRow label="Source" value={result.data.source || '—'} />
                <InfoRow label="Updated" value={fmtDate(result.data.updatedAt)} />
              </div>
            </div>
          )}

          {/* UTXOs */}
          {activeTab === 'utxos' && (
            <div className="card">
              <div className="card-header">
                <span className="text-brand-yellow">◇</span>
                <span className="section-title flex-1">UTXOs (sorted by amount ↓)</span>
                <span className="badge badge-yellow">{result.data?.utxos?.length || 0}</span>
              </div>
              {!result.data?.utxos?.length ? (
                <div className="p-6 text-center text-gray-600 font-mono text-sm">No UTXOs found</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr>
                        <th className="table-head">TXID</th>
                        <th className="table-head">Vout</th>
                        <th className="table-head">Amount</th>
                        <th className="table-head">Confs</th>
                        <th className="table-head">Spent</th>
                      </tr>
                    </thead>
                    <tbody>
                      {result.data.utxos.map((u, i) => (
                        <tr key={i} className="hover:bg-dark-700/30">
                          <td className="table-cell"><span className="hash">{shortHash(u.txid)}</span></td>
                          <td className="table-cell text-gray-400">{u.vout}</td>
                          <td className="table-cell text-brand-green font-bold">{u.amount?.toFixed(8)}</td>
                          <td className="table-cell text-brand-cyan">{u.confirmations}</td>
                          <td className="table-cell">
                            <span className={`badge ${u.spent ? 'badge-red' : 'badge-green'}`}>
                              {u.spent ? 'SPENT' : 'UNSPENT'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Txs */}
          {activeTab === 'txs' && (
            <div className="card">
              <div className="card-header">
                <span className="text-brand-cyan">⇄</span>
                <span className="section-title flex-1">Recent Transactions</span>
              </div>
              {!result.data?.recentTxs?.length ? (
                <div className="p-6 text-center text-gray-600 font-mono text-sm">No transactions cached</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr>
                        <th className="table-head">TXID</th>
                        <th className="table-head">Status</th>
                        <th className="table-head">Confs</th>
                        <th className="table-head">Value</th>
                        <th className="table-head">Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {result.data.recentTxs.map(tx => (
                        <tr key={tx._id} className="hover:bg-dark-700/30">
                          <td className="table-cell"><span className="hash">{shortHash(tx.txid)}</span></td>
                          <td className="table-cell">
                            <span className={`badge ${tx.status === 'confirmed' ? 'badge-green' : tx.status === 'pending' ? 'badge-yellow' : 'badge-red'}`}>
                              {tx.status?.toUpperCase()}
                            </span>
                          </td>
                          <td className="table-cell text-brand-cyan">{tx.confirmations}</td>
                          <td className="table-cell text-brand-green">{tx.value?.toFixed(6)}</td>
                          <td className="table-cell text-gray-500">{fmtDate(tx.timestamp)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function InfoRow({ label, value, mono, highlight }) {
  const colors = { green: 'text-brand-green', cyan: 'text-brand-cyan', yellow: 'text-brand-yellow' };
  return (
    <div className="flex items-start gap-4 py-2.5 border-b border-dark-500/50 last:border-0">
      <span className="text-xs font-bold tracking-widest uppercase text-gray-500 font-sans w-36 shrink-0 pt-0.5">{label}</span>
      <span className={`font-mono text-sm break-all ${highlight ? colors[highlight] : 'text-gray-300'}`}>
        {value}
      </span>
    </div>
  );
}
