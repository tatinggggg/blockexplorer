import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { useWS } from '../contexts/WSContext';

const shortHash = (h) => h ? h.slice(0, 10) + '…' + h.slice(-6) : '—';
const fmtTime = (ts) => ts ? new Date(ts).toLocaleTimeString() : '—';
const fmtDate = (ts) => ts ? new Date(ts).toLocaleString() : '—';

function StatCard({ label, value, sub, color = 'cyan' }) {
  const colors = {
    cyan: 'text-brand-cyan',
    green: 'text-brand-green',
    purple: 'text-brand-purple',
    orange: 'text-brand-orange',
    yellow: 'text-brand-yellow',
  };
  return (
    <div className="card p-4 hover:border-dark-400 transition-colors">
      <div className="label">{label}</div>
      <div className={`font-mono text-2xl font-bold ${colors[color]}`}>{value}</div>
      {sub && <div className="text-xs text-gray-600 font-mono mt-1">{sub}</div>}
    </div>
  );
}

export default function Home() {
  const [blocks, setBlocks] = useState([]);
  const [mempool, setMempool] = useState([]);
  const [stats, setStats] = useState(null);
  const [miningLoading, setMiningLoading] = useState(false);
  const [mineMsg, setMineMsg] = useState('');
  const { lastMessage, connected } = useWS();

  const fetchData = useCallback(async () => {
    try {
      const [blocksRes, mempoolRes, statsRes] = await Promise.all([
        axios.get('/api/blocks?limit=10'),
        axios.get('/api/tx/mempool/list'),
        axios.get('/api/health'),
      ]);
      setBlocks(blocksRes.data.blocks || []);
      setMempool(mempoolRes.data.transactions || []);
      setStats(statsRes.data);
    } catch (err) {
      console.error(err);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  // React to WebSocket events
  useEffect(() => {
    if (!lastMessage) return;
    if (lastMessage.type === 'NEW_BLOCK' || lastMessage.type === 'NEW_TX') {
      fetchData();
    }
  }, [lastMessage, fetchData]);

  const mineBlock = async () => {
    setMiningLoading(true);
    setMineMsg('');
    try {
      const res = await axios.post('/api/blocks/mine', { miner: 'Admin Miner' });
      setMineMsg(`✓ ${res.data.message}`);
      fetchData();
    } catch (err) {
      setMineMsg(`✗ ${err.response?.data?.error || 'Mining failed'}`);
    } finally {
      setMiningLoading(false);
      setTimeout(() => setMineMsg(''), 4000);
    }
  };

  return (
    <div className="p-6 animate-fade-in">
      {/* Page header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-sans font-bold text-xl text-gray-100 tracking-wide">
            Block Explorer
          </h1>
          <p className="text-xs text-gray-500 font-mono mt-0.5">
            Internal chain + hybrid lookup engine
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded border ${
            connected ? 'bg-brand-green/5 border-brand-green/20 text-brand-green' : 'bg-brand-red/5 border-brand-red/20 text-brand-red'
          }`}>
            <div className={`w-1.5 h-1.5 rounded-full ${connected ? 'bg-brand-green' : 'bg-brand-red'} animate-pulse`} />
            <span className="font-mono text-xs">{connected ? 'Live' : 'Offline'}</span>
          </div>
          <button
            onClick={mineBlock}
            disabled={miningLoading}
            className="btn-success flex items-center gap-2"
          >
            <span>⛏</span>
            {miningLoading ? 'Mining…' : 'Mine Block'}
          </button>
        </div>
      </div>

      {/* Mine message */}
      {mineMsg && (
        <div className={`mb-4 px-4 py-2 rounded font-mono text-xs border ${
          mineMsg.startsWith('✓') ? 'bg-brand-green/10 border-brand-green/30 text-brand-green' : 'bg-brand-red/10 border-brand-red/30 text-brand-red'
        }`}>
          {mineMsg}
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Blocks" value={blocks.length > 0 ? blocks[0]?.height || 0 : 0} color="cyan" />
        <StatCard label="Mempool Size" value={mempool.length} sub="Pending txs" color="yellow" />
        <StatCard
          label="Latest Block"
          value={blocks[0] ? `#${blocks[0].height}` : '—'}
          sub={blocks[0] ? fmtTime(blocks[0].timestamp) : ''}
          color="green"
        />
        <StatCard
          label="WS Clients"
          value={stats?.wsClients ?? '—'}
          sub={`DB: ${stats?.db || '—'}`}
          color="purple"
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Recent Blocks */}
        <div className="card">
          <div className="card-header">
            <span className="text-brand-cyan">⬡</span>
            <span className="section-title flex-1">Recent Blocks</span>
            <span className="badge badge-green text-xs">INTERNAL CHAIN</span>
          </div>
          {blocks.length === 0 ? (
            <div className="p-8 text-center text-gray-600 font-mono text-sm">
              No blocks mined yet.<br />Click "Mine Block" to start.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr>
                    <th className="table-head">Height</th>
                    <th className="table-head">Hash</th>
                    <th className="table-head">Txs</th>
                    <th className="table-head">Fees</th>
                    <th className="table-head">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {blocks.map(b => (
                    <tr key={b._id} className="hover:bg-dark-700/30 transition-colors">
                      <td className="table-cell text-brand-cyan font-bold">#{b.height}</td>
                      <td className="table-cell"><span className="hash">{shortHash(b.hash)}</span></td>
                      <td className="table-cell text-brand-green">{b.txCount}</td>
                      <td className="table-cell text-brand-yellow">{b.totalFees?.toFixed(6) || '0'}</td>
                      <td className="table-cell text-gray-500">{fmtTime(b.timestamp)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Mempool */}
        <div className="card">
          <div className="card-header">
            <span className="text-brand-yellow">⇄</span>
            <span className="section-title flex-1">Mempool</span>
            <span className="badge badge-yellow">{mempool.length} PENDING</span>
          </div>
          {mempool.length === 0 ? (
            <div className="p-8 text-center text-gray-600 font-mono text-sm">
              Mempool is empty.<br />Broadcast a transaction to add it.
            </div>
          ) : (
            <div className="overflow-x-auto max-h-80 overflow-y-auto">
              <table className="w-full">
                <thead>
                  <tr>
                    <th className="table-head">TXID</th>
                    <th className="table-head">Chain</th>
                    <th className="table-head">Value</th>
                    <th className="table-head">Fee</th>
                    <th className="table-head">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {mempool.map(tx => (
                    <tr key={tx._id} className="hover:bg-dark-700/30 transition-colors">
                      <td className="table-cell"><span className="hash">{shortHash(tx.txid)}</span></td>
                      <td className="table-cell">
                        <span className={`badge ${tx.chain === 'BTC' ? 'badge-orange' : tx.chain === 'ETH' ? 'badge-purple' : 'badge-yellow'}`}>
                          {tx.chain}
                        </span>
                      </td>
                      <td className="table-cell text-brand-green">{(tx.value || 0).toFixed(6)}</td>
                      <td className="table-cell text-brand-yellow">{(tx.fee || 0).toFixed(6)}</td>
                      <td className="table-cell text-gray-500">{fmtTime(tx.timestamp)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* WebSocket Live Feed */}
      <div className="card mt-6">
        <div className="card-header">
          <span className="text-brand-cyan">◉</span>
          <span className="section-title flex-1">Live Event Feed</span>
          <span className={`badge ${connected ? 'badge-green' : 'badge-red'}`}>
            {connected ? 'LIVE' : 'OFFLINE'}
          </span>
        </div>
        <WSFeed />
      </div>
    </div>
  );
}

function WSFeed() {
  const { messages } = useWS();

  return (
    <div className="p-4 h-40 overflow-y-auto bg-dark-900/50 font-mono text-xs space-y-1">
      {messages.length === 0 && (
        <span className="text-gray-600">Waiting for events…</span>
      )}
      {messages.map((m, i) => (
        <div key={i} className="flex gap-3">
          <span className="text-gray-600 shrink-0">
            {new Date(m.receivedAt).toLocaleTimeString()}
          </span>
          <span className={
            m.type === 'NEW_BLOCK' ? 'text-brand-green' :
            m.type === 'NEW_TX' ? 'text-brand-cyan' :
            m.type === 'CONNECTED' ? 'text-brand-purple' :
            'text-gray-400'
          }>
            [{m.type}]
          </span>
          <span className="text-gray-400">
            {m.data ? JSON.stringify(m.data).slice(0, 80) : m.message}
          </span>
        </div>
      ))}
    </div>
  );
}
