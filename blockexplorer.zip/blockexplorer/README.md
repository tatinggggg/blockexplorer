# ⬡ BlockXplorer — Developer Tools

> A full-stack blockchain explorer with internal simulation capabilities, hybrid lookup (MongoDB → public RPC), real-time WebSocket updates, and a comprehensive developer toolset.

---

## 🏗 Architecture

```
blockexplorer/
├── backend/               Node.js + Express + MongoDB + WebSocket
│   ├── models/            Mongoose schemas (Address, Transaction, UTXO, Block)
│   ├── routes/            API endpoints
│   ├── middleware/        JWT auth
│   └── utils/             RPC connector + crypto utilities
└── frontend/              React + Vite + TailwindCSS
    └── src/
        ├── pages/         Home, AddressLookup, TransactionLookup, DevTools, Admin
        ├── components/    Sidebar, Layout
        └── contexts/      AuthContext, WSContext
```

---

## ⚡ Quick Start

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)

### 1. Backend

```bash
cd backend
npm install
cp .env .env.local   # edit as needed
npm run dev          # starts on :3001
```

### 2. Frontend

```bash
cd frontend
npm install
npm run dev          # starts on :5173
```

### 3. Login
```
URL:      http://localhost:5173
Username: admin
Password: @Ak3s1t4m!
```

---

## 🔐 Authentication

- JWT-based, single hardcoded admin account
- No registration
- Token stored in `localStorage`, 24h expiry
- All admin/protected routes require `Authorization: Bearer <token>`

---

## 🗄 Database Collections

| Collection    | Key Fields |
|---------------|------------|
| `addresses`   | address, chain, balance, notes, source, createdAt |
| `transactions`| txid, chain, inputs[], outputs[], rawHex, status, confirmations, timestamp |
| `utxos`       | txid, vout, address, chain, amount, spent, confirmations |
| `blocks`      | height, hash, previousHash, merkleRoot, transactions[], txCount, timestamp |

---

## 🔁 Hybrid Lookup Logic

### Address / Transaction Lookup:
```
1. Query MongoDB  →  found? return from DB
                 ↘  not found?
2. Fetch public RPC  →  cache in MongoDB  →  return
```

### Supported Chains:
| Chain | API Used |
|-------|----------|
| BTC   | Blockstream API (blockstream.info/api) |
| ETH   | Cloudflare ETH RPC (cloudflare-eth.com) |
| BSC   | Binance public RPC (bsc-dataseed.binance.org) |

---

## 📡 WebSocket Events

All clients connected to `ws://localhost:3001` receive:

| Event Type      | Trigger |
|----------------|---------|
| `CONNECTED`     | On connect |
| `NEW_TX`        | Transaction broadcasted |
| `NEW_BLOCK`     | Block mined |
| `MEMPOOL_CLEARED` | Admin cleared mempool |
| `DATA_RESET`    | Admin reset all data |

---

## ⛏ Mining Simulator

POST `/api/blocks/mine` (requires auth):
- Collects all pending transactions
- Creates a new block with computed merkle root + hash
- Updates tx status to `confirmed`
- Increments confirmations for all confirmed txs
- Emits `NEW_BLOCK` WebSocket event

---

## 📡 REST API Reference

### Auth
```
POST /api/auth/login         { username, password }
POST /api/auth/verify        { token }
```

### Addresses
```
GET  /api/address/:chain/:address    Hybrid lookup
POST /api/address                    Create/update (auth)
POST /api/address/generate/bulk      Bulk generate (auth)
DELETE /api/address/:id              Delete (auth)
```

### Transactions
```
GET  /api/tx/:chain/:txid            Hybrid lookup
POST /api/tx/broadcast               Internal broadcast (no signature check)
GET  /api/tx/mempool/list            Pending transactions
GET  /api/tx                         List all (auth)
DELETE /api/tx/:id                   Delete (auth)
```

### Blocks
```
GET  /api/blocks                     List recent blocks
GET  /api/blocks/latest              Latest block
GET  /api/blocks/:height             Block by height
POST /api/blocks/mine                Mine new block (auth)
```

### UTXOs
```
GET  /api/utxo/:chain/:address       UTXOs for address (sorted ↓)
GET  /api/utxo                       All UTXOs (auth)
POST /api/utxo                       Create UTXO (auth)
PATCH /api/utxo/:id/spend            Mark spent (auth)
```

### Admin
```
GET  /api/admin/stats                Dashboard stats
POST /api/admin/generate-addresses   Generate addresses
POST /api/admin/calculate-fee        Fee calculator
POST /api/admin/clear-mempool        Clear pending txs
POST /api/admin/reset-all            Wipe all data
GET  /api/admin/addresses            Paginated address list
GET  /api/admin/transactions         Paginated tx list
```

---

## 🛠 Developer Tools

| Tool | Description |
|------|-------------|
| Address Generator | Generate BTC (P2PKH + WIF) or ETH/BSC addresses |
| Bulk CSV Export | Export up to 1000 addresses as CSV |
| UTXO List | Sorted descending by amount, hybrid lookup |
| Fee Calculator | BTC fee estimation (inputs × 148 + outputs × 34 + 10) |
| Raw TX Builder | Build multi-input/output transactions with fee display |
| Internal Broadcast | POST raw/unsigned tx → generates SHA256 txid → mempool |
| Mempool View | Real-time pending transaction table |

---

## ⚠ Important Notes

1. **Broadcast is internal only** — transactions are never sent to any real blockchain
2. **Unsigned transactions accepted** — no signature verification
3. **TXID generation** — uses double-SHA256 of rawHex (or random bytes if none provided)
4. **Address generation** — simplified cryptographic implementation for demo purposes. Do NOT use generated keys for real funds.
5. **Public RPC limits** — Blockstream and public ETH/BSC RPCs have rate limits; add your own endpoints in `.env` for production use.
