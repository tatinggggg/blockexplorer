const mongoose = require('mongoose');

const inputSchema = new mongoose.Schema({
  txid: String,
  vout: Number,
  address: String,
  amount: Number,
  scriptSig: String,
  sequence: Number,
}, { _id: false });

const outputSchema = new mongoose.Schema({
  address: String,
  amount: Number,
  scriptPubKey: String,
  n: Number,
}, { _id: false });

const transactionSchema = new mongoose.Schema({
  txid: { type: String, required: true, unique: true, index: true },
  chain: { type: String, required: true, enum: ['BTC', 'ETH', 'BSC'], default: 'BTC' },
  inputs: [inputSchema],
  outputs: [outputSchema],
  rawHex: { type: String, default: '' },
  status: { type: String, enum: ['pending', 'confirmed', 'failed'], default: 'pending' },
  confirmations: { type: Number, default: 0 },
  blockHeight: { type: Number, default: null },
  blockHash: { type: String, default: null },
  fee: { type: Number, default: 0 },
  size: { type: Number, default: 0 },
  // ETH-specific
  from: { type: String, default: null },
  to: { type: String, default: null },
  value: { type: Number, default: 0 },
  gasUsed: { type: Number, default: null },
  gasPrice: { type: Number, default: null },
  nonce: { type: Number, default: null },
  source: { type: String, enum: ['broadcast', 'rpc', 'internal'], default: 'broadcast' },
  timestamp: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Transaction', transactionSchema);
