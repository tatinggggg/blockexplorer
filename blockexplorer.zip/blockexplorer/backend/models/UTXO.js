const mongoose = require('mongoose');

const utxoSchema = new mongoose.Schema({
  txid: { type: String, required: true, index: true },
  vout: { type: Number, required: true },
  address: { type: String, required: true, index: true },
  chain: { type: String, required: true, enum: ['BTC', 'ETH', 'BSC'], default: 'BTC' },
  amount: { type: Number, required: true },
  confirmations: { type: Number, default: 0 },
  spent: { type: Boolean, default: false },
  spentBy: { type: String, default: null },
  blockHeight: { type: Number, default: null },
  source: { type: String, enum: ['rpc', 'internal'], default: 'internal' },
  createdAt: { type: Date, default: Date.now },
});

utxoSchema.index({ txid: 1, vout: 1 }, { unique: true });

module.exports = mongoose.model('UTXO', utxoSchema);
