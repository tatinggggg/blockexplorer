const mongoose = require('mongoose');

const addressSchema = new mongoose.Schema({
  address: { type: String, required: true, index: true },
  chain: { type: String, required: true, enum: ['BTC', 'ETH', 'BSC'], default: 'BTC' },
  balance: { type: Number, default: 0 },
  notes: { type: String, default: '' },
  // Extended fields from RPC fetch
  txCount: { type: Number, default: 0 },
  totalReceived: { type: Number, default: 0 },
  totalSent: { type: Number, default: 0 },
  source: { type: String, enum: ['manual', 'rpc', 'internal'], default: 'manual' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

addressSchema.index({ address: 1, chain: 1 }, { unique: true });

addressSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Address', addressSchema);
