const mongoose = require('mongoose');

const blockSchema = new mongoose.Schema({
  height: { type: Number, required: true, unique: true, index: true },
  hash: { type: String, required: true, unique: true },
  previousHash: { type: String, default: '0000000000000000000000000000000000000000000000000000000000000000' },
  merkleRoot: { type: String, default: '' },
  transactions: [{ type: String }], // array of txids
  txCount: { type: Number, default: 0 },
  totalFees: { type: Number, default: 0 },
  totalAmount: { type: Number, default: 0 },
  difficulty: { type: Number, default: 1 },
  nonce: { type: Number, default: 0 },
  size: { type: Number, default: 0 },
  miner: { type: String, default: 'Internal Miner' },
  chain: { type: String, default: 'BTC' },
  timestamp: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Block', blockSchema);
