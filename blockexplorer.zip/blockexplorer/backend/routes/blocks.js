const express = require('express');
const router = express.Router();
const Block = require('../models/Block');
const Transaction = require('../models/Transaction');
const UTXO = require('../models/UTXO');
const { generateBlockHash, computeMerkleRoot } = require('../utils/crypto');
const authMiddleware = require('../middleware/auth');

// GET /api/blocks — list recent blocks
router.get('/', async (req, res) => {
  const { limit = 20, page = 1 } = req.query;
  try {
    const total = await Block.countDocuments();
    const blocks = await Block.find()
      .sort({ height: -1 })
      .skip((parseInt(page) - 1) * parseInt(limit))
      .limit(parseInt(limit));
    res.json({ total, page: parseInt(page), blocks });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/blocks/latest
router.get('/latest', async (req, res) => {
  try {
    const block = await Block.findOne().sort({ height: -1 });
    res.json({ data: block });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/blocks/:height
router.get('/:height', async (req, res) => {
  try {
    const block = await Block.findOne({ height: parseInt(req.params.height) });
    if (!block) return res.status(404).json({ error: 'Block not found' });

    const txs = await Transaction.find({ txid: { $in: block.transactions } });
    res.json({ data: { ...block.toObject(), txDetails: txs } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/blocks/mine — Mine a new block
// Collects pending transactions, creates block, increases confirmations
router.post('/mine', authMiddleware, async (req, res) => {
  try {
    const broadcast = req.app.get('broadcast');

    // Get latest block for height + previousHash
    const latestBlock = await Block.findOne().sort({ height: -1 });
    const height = latestBlock ? latestBlock.height + 1 : 1;
    const previousHash = latestBlock ? latestBlock.hash : '0'.repeat(64);

    // Collect pending transactions
    const pendingTxs = await Transaction.find({ status: 'pending' })
      .sort({ timestamp: 1 })
      .limit(100);

    const txids = pendingTxs.map(tx => tx.txid);
    const timestamp = Date.now();
    const nonce = Math.floor(Math.random() * 0xffffffff);
    const merkleRoot = computeMerkleRoot(txids);
    const blockHash = generateBlockHash(height, previousHash, merkleRoot, timestamp, nonce);

    // Calculate totals
    const totalFees = pendingTxs.reduce((s, tx) => s + (tx.fee || 0), 0);
    const totalAmount = pendingTxs.reduce((s, tx) => s + (tx.value || 0), 0);

    // Create block
    const block = new Block({
      height,
      hash: blockHash,
      previousHash,
      merkleRoot,
      transactions: txids,
      txCount: txids.length,
      totalFees,
      totalAmount,
      nonce,
      size: Math.floor(Math.random() * 500000) + 100000,
      miner: req.body.miner || 'Internal Miner',
      chain: req.body.chain || 'BTC',
      timestamp: new Date(timestamp),
    });

    await block.save();

    // Update transaction status to confirmed, increase confirmations
    await Transaction.updateMany(
      { txid: { $in: txids } },
      {
        $set: {
          status: 'confirmed',
          blockHeight: height,
          blockHash,
        },
        $inc: { confirmations: 1 },
      }
    );

    // Update UTXOs confirmations
    await UTXO.updateMany(
      { txid: { $in: txids } },
      { $inc: { confirmations: 1 } }
    );

    // Increment confirmations of all previously confirmed txs
    await Transaction.updateMany(
      { status: 'confirmed', blockHeight: { $lt: height, $ne: null } },
      { $inc: { confirmations: 1 } }
    );

    // WebSocket broadcast
    if (broadcast) {
      broadcast({
        type: 'NEW_BLOCK',
        data: {
          height,
          hash: blockHash,
          txCount: txids.length,
          totalFees,
          timestamp: new Date(timestamp),
          minedTxIds: txids,
        },
      });
    }

    res.status(201).json({
      success: true,
      block: block.toObject(),
      minedTransactions: txids.length,
      message: `Block #${height} mined with ${txids.length} transaction(s)`,
    });

  } catch (err) {
    console.error('[MINE]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/blocks/:id — requires auth
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    await Block.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
