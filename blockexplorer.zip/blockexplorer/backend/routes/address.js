const express = require('express');
const router = express.Router();
const Address = require('../models/Address');
const UTXO = require('../models/UTXO');
const Transaction = require('../models/Transaction');
const { fetchAddressFromRPC, fetchUTXOFromRPC } = require('../utils/rpc');
const { generateBTCAddress, generateETHAddress, generateWIF } = require('../utils/crypto');
const authMiddleware = require('../middleware/auth');

// GET /api/address/:chain/:address
// STEP 1: Check MongoDB → STEP 2: Fallback to RPC
router.get('/:chain/:address', async (req, res) => {
  const { chain, address } = req.params;
  const validChains = ['BTC', 'ETH', 'BSC'];

  if (!validChains.includes(chain.toUpperCase())) {
    return res.status(400).json({ error: `Unsupported chain. Use: ${validChains.join(', ')}` });
  }

  try {
    // STEP 1: Check MongoDB
    let dbRecord = await Address.findOne({ address, chain: chain.toUpperCase() });
    let source = 'db';

    if (dbRecord) {
      // Fetch related UTXOs and recent transactions from DB
      const utxos = await UTXO.find({ address, chain: chain.toUpperCase(), spent: false })
        .sort({ amount: -1 }).limit(50);
      const txs = await Transaction.find({
        chain: chain.toUpperCase(),
        $or: [
          { 'inputs.address': address },
          { 'outputs.address': address },
          { from: address },
          { to: address },
        ]
      }).sort({ timestamp: -1 }).limit(20);

      return res.json({
        source,
        data: {
          ...dbRecord.toObject(),
          utxos,
          recentTxs: txs,
        },
      });
    }

    // STEP 2: Fetch from public RPC
    source = 'rpc';
    let rpcData;
    try {
      rpcData = await fetchAddressFromRPC(chain.toUpperCase(), address);
    } catch (rpcErr) {
      return res.status(404).json({
        error: 'Address not found in database or public chain',
        detail: rpcErr.message,
      });
    }

    // Cache in MongoDB
    dbRecord = await Address.findOneAndUpdate(
      { address, chain: chain.toUpperCase() },
      { ...rpcData, updatedAt: new Date() },
      { upsert: true, new: true }
    );

    // Fetch UTXOs from RPC if BTC
    let utxos = [];
    if (chain.toUpperCase() === 'BTC') {
      try {
        const rpcUtxos = await fetchUTXOFromRPC(chain.toUpperCase(), address);
        for (const u of rpcUtxos) {
          await UTXO.findOneAndUpdate(
            { txid: u.txid, vout: u.vout },
            u,
            { upsert: true, new: true }
          );
        }
        utxos = rpcUtxos;
      } catch (_) {
        // UTXO fetch failed, continue without
      }
    }

    res.json({ source, data: { ...dbRecord.toObject(), utxos, recentTxs: [] } });

  } catch (err) {
    console.error('[ADDRESS]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// GET /api/address/:chain/:address/utxo
router.get('/:chain/:address/utxo', async (req, res) => {
  const { chain, address } = req.params;
  try {
    let utxos = await UTXO.find({ address, chain: chain.toUpperCase(), spent: false })
      .sort({ amount: -1 });

    if (utxos.length === 0 && chain.toUpperCase() === 'BTC') {
      try {
        const rpcUtxos = await fetchUTXOFromRPC(chain.toUpperCase(), address);
        utxos = rpcUtxos;
      } catch (_) {}
    }

    res.json({ address, chain, count: utxos.length, utxos });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/address (create/update manual entry) — requires auth
router.post('/', authMiddleware, async (req, res) => {
  const { address, chain, balance, notes } = req.body;
  if (!address || !chain) {
    return res.status(400).json({ error: 'address and chain are required' });
  }
  try {
    const record = await Address.findOneAndUpdate(
      { address, chain: chain.toUpperCase() },
      { address, chain: chain.toUpperCase(), balance: balance || 0, notes: notes || '', source: 'manual', updatedAt: new Date() },
      { upsert: true, new: true }
    );
    res.json({ success: true, data: record });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/address/:id — requires auth
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    await Address.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/address/generate — generate new addresses
router.post('/generate/bulk', authMiddleware, async (req, res) => {
  const { chain = 'BTC', count = 10 } = req.body;
  const num = Math.min(parseInt(count), 1000);

  const addresses = [];
  for (let i = 0; i < num; i++) {
    if (chain === 'BTC') {
      const wif = generateWIF();
      addresses.push({ chain: 'BTC', ...wif });
    } else {
      const eth = generateETHAddress();
      addresses.push({ chain, ...eth });
    }
  }

  res.json({ chain, count: num, addresses });
});

module.exports = router;
