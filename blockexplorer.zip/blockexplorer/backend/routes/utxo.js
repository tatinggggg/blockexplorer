const express = require('express');
const router = express.Router();
const UTXO = require('../models/UTXO');
const { fetchUTXOFromRPC } = require('../utils/rpc');
const authMiddleware = require('../middleware/auth');

// GET /api/utxo — list all UTXOs (admin), sorted descending by amount
router.get('/', authMiddleware, async (req, res) => {
  const { address, chain, spent, page = 1, limit = 50 } = req.query;
  const filter = {};
  if (address) filter.address = address;
  if (chain) filter.chain = chain.toUpperCase();
  if (spent !== undefined) filter.spent = spent === 'true';

  try {
    const total = await UTXO.countDocuments(filter);
    const utxos = await UTXO.find(filter)
      .sort({ amount: -1 })
      .skip((parseInt(page) - 1) * parseInt(limit))
      .limit(parseInt(limit));

    res.json({ total, page: parseInt(page), utxos });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/utxo/:chain/:address — UTXOs for address (hybrid)
router.get('/:chain/:address', async (req, res) => {
  const { chain, address } = req.params;
  try {
    // Check DB first
    let utxos = await UTXO.find({ address, chain: chain.toUpperCase(), spent: false })
      .sort({ amount: -1 });

    let source = 'db';

    // If empty and BTC, try RPC
    if (utxos.length === 0 && chain.toUpperCase() === 'BTC') {
      try {
        const rpcUtxos = await fetchUTXOFromRPC('BTC', address);
        // Save to DB
        for (const u of rpcUtxos) {
          await UTXO.findOneAndUpdate(
            { txid: u.txid, vout: u.vout },
            u,
            { upsert: true, new: true }
          );
        }
        utxos = await UTXO.find({ address, chain: 'BTC', spent: false }).sort({ amount: -1 });
        source = 'rpc';
      } catch (_) {}
    }

    const totalAmount = utxos.reduce((s, u) => s + u.amount, 0);
    res.json({ address, chain, source, count: utxos.length, totalAmount, utxos });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/utxo — create manual UTXO
router.post('/', authMiddleware, async (req, res) => {
  try {
    const utxo = new UTXO({ ...req.body, source: 'internal' });
    await utxo.save();
    res.status(201).json({ success: true, data: utxo });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/utxo/:id/spend — mark UTXO as spent
router.patch('/:id/spend', authMiddleware, async (req, res) => {
  try {
    const utxo = await UTXO.findByIdAndUpdate(
      req.params.id,
      { spent: true, spentBy: req.body.spentBy || null },
      { new: true }
    );
    if (!utxo) return res.status(404).json({ error: 'UTXO not found' });
    res.json({ success: true, data: utxo });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/utxo/:id
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    await UTXO.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
