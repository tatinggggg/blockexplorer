const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');
const UTXO = require('../models/UTXO');
const { fetchTransactionFromRPC } = require('../utils/rpc');
const { generateTxid } = require('../utils/crypto');
const authMiddleware = require('../middleware/auth');

// GET /api/tx/:chain/:txid  — hybrid lookup
router.get('/:chain/:txid', async (req, res) => {
  const { chain, txid } = req.params;

  try {
    // STEP 1: MongoDB
    let tx = await Transaction.findOne({ txid, chain: chain.toUpperCase() });
    if (!tx) tx = await Transaction.findOne({ txid }); // chain-agnostic fallback

    if (tx) {
      return res.json({ source: 'db', data: tx });
    }

    // STEP 2: RPC
    let rpcTx;
    try {
      rpcTx = await fetchTransactionFromRPC(chain.toUpperCase(), txid);
    } catch (rpcErr) {
      return res.status(404).json({
        error: 'Transaction not found in database or public chain',
        detail: rpcErr.message,
      });
    }

    // Cache it
    tx = await Transaction.findOneAndUpdate(
      { txid },
      { ...rpcTx, chain: chain.toUpperCase() },
      { upsert: true, new: true }
    );

    res.json({ source: 'rpc', data: tx });
  } catch (err) {
    console.error('[TX GET]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/tx/broadcast — internal only, no real blockchain submission
// Accepts unsigned tx, skips signature verification, generates txid via SHA256
router.post('/broadcast', async (req, res) => {
  const {
    chain = 'BTC',
    rawHex,
    inputs = [],
    outputs = [],
    from,
    to,
    value,
    gasPrice,
    nonce,
    fee = 0,
    size = 0,
  } = req.body;

  // Generate txid from rawHex or random data
  const txid = generateTxid(rawHex);

  // Compute total input/output amounts
  const totalIn = inputs.reduce((s, i) => s + (parseFloat(i.amount) || 0), 0);
  const totalOut = outputs.reduce((s, o) => s + (parseFloat(o.amount) || 0), 0);

  try {
    const tx = new Transaction({
      txid,
      chain: chain.toUpperCase(),
      rawHex: rawHex || '',
      inputs: inputs.map((inp, i) => ({
        txid: inp.txid || txid,
        vout: inp.vout ?? i,
        address: inp.address || inp.from || '',
        amount: parseFloat(inp.amount) || 0,
        scriptSig: inp.scriptSig || '',
        sequence: inp.sequence || 0xffffffff,
      })),
      outputs: outputs.map((out, i) => ({
        n: i,
        address: out.address || out.to || '',
        amount: parseFloat(out.amount) || 0,
        scriptPubKey: out.scriptPubKey || '',
      })),
      from: from || inputs[0]?.address || null,
      to: to || outputs[0]?.address || null,
      value: parseFloat(value) || totalOut,
      gasPrice: gasPrice ? parseFloat(gasPrice) : null,
      nonce: nonce !== undefined ? parseInt(nonce) : null,
      fee: parseFloat(fee) || Math.max(0, totalIn - totalOut),
      size: parseInt(size) || (rawHex ? rawHex.length / 2 : 250),
      status: 'pending',
      confirmations: 0,
      source: 'broadcast',
      timestamp: new Date(),
    });

    await tx.save();

    // Create UTXOs for outputs (BTC-style)
    if (chain.toUpperCase() === 'BTC') {
      for (const [i, out] of outputs.entries()) {
        if (out.address) {
          await UTXO.findOneAndUpdate(
            { txid, vout: i },
            {
              txid, vout: i,
              address: out.address,
              chain: 'BTC',
              amount: parseFloat(out.amount) || 0,
              confirmations: 0,
              spent: false,
              source: 'internal',
            },
            { upsert: true, new: true }
          );
        }
      }
    }

    // Broadcast WebSocket update
    const broadcast = req.app.get('broadcast');
    if (broadcast) {
      broadcast({
        type: 'NEW_TX',
        data: { txid, chain: chain.toUpperCase(), status: 'pending', timestamp: new Date() },
      });
    }

    res.status(201).json({
      success: true,
      txid,
      status: 'pending',
      message: 'Transaction accepted into internal mempool (not broadcast to real blockchain)',
    });
  } catch (err) {
    console.error('[TX BROADCAST]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// GET /api/tx/mempool/list — pending transactions
router.get('/mempool/list', async (req, res) => {
  try {
    const pending = await Transaction.find({ status: 'pending' })
      .sort({ timestamp: -1 })
      .limit(100);
    res.json({ count: pending.length, transactions: pending });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/tx (list all) — requires auth
router.get('/', authMiddleware, async (req, res) => {
  const { page = 1, limit = 20, status, chain } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (chain) filter.chain = chain.toUpperCase();

  try {
    const total = await Transaction.countDocuments(filter);
    const txs = await Transaction.find(filter)
      .sort({ timestamp: -1 })
      .skip((parseInt(page) - 1) * parseInt(limit))
      .limit(parseInt(limit));

    res.json({ total, page: parseInt(page), limit: parseInt(limit), transactions: txs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/tx/:id — requires auth
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    await Transaction.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
