const express = require('express');
const router = express.Router();
const Address = require('../models/Address');
const Transaction = require('../models/Transaction');
const UTXO = require('../models/UTXO');
const Block = require('../models/Block');
const { generateBTCAddress, generateETHAddress, generateWIF, calculateFee } = require('../utils/crypto');
const authMiddleware = require('../middleware/auth');

// All admin routes require auth
router.use(authMiddleware);

// GET /api/admin/stats
router.get('/stats', async (req, res) => {
  try {
    const [addresses, transactions, utxos, blocks, pending, confirmed] = await Promise.all([
      Address.countDocuments(),
      Transaction.countDocuments(),
      UTXO.countDocuments({ spent: false }),
      Block.countDocuments(),
      Transaction.countDocuments({ status: 'pending' }),
      Transaction.countDocuments({ status: 'confirmed' }),
    ]);

    const latestBlock = await Block.findOne().sort({ height: -1 });
    const recentTxs = await Transaction.find().sort({ timestamp: -1 }).limit(10);
    const recentBlocks = await Block.find().sort({ height: -1 }).limit(5);

    res.json({
      stats: { addresses, transactions, utxos, blocks, pending, confirmed },
      latestBlock,
      recentTxs,
      recentBlocks,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/generate-addresses
router.post('/generate-addresses', async (req, res) => {
  const { chain = 'BTC', count = 10 } = req.body;
  const num = Math.min(parseInt(count), 1000);

  const addresses = [];
  for (let i = 0; i < num; i++) {
    if (chain === 'BTC') {
      const wif = generateWIF();
      addresses.push({ chain: 'BTC', ...wif });
    } else {
      const eth = generateETHAddress();
      addresses.push({ chain, ...eth });
    }
  }

  res.json({ chain, count: num, addresses });
});

// POST /api/admin/calculate-fee
router.post('/calculate-fee', async (req, res) => {
  const { inputCount = 1, outputCount = 2, feeRatePerByte = 10 } = req.body;
  const result = calculateFee(
    parseInt(inputCount),
    parseInt(outputCount),
    parseInt(feeRatePerByte)
  );
  res.json(result);
});

// POST /api/admin/clear-mempool — clear pending transactions
router.post('/clear-mempool', async (req, res) => {
  try {
    const result = await Transaction.deleteMany({ status: 'pending' });
    const broadcast = req.app.get('broadcast');
    if (broadcast) broadcast({ type: 'MEMPOOL_CLEARED', data: { count: result.deletedCount } });
    res.json({ success: true, cleared: result.deletedCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/reset-all — wipe all internal data
router.post('/reset-all', async (req, res) => {
  try {
    await Promise.all([
      Address.deleteMany({}),
      Transaction.deleteMany({}),
      UTXO.deleteMany({}),
      Block.deleteMany({}),
    ]);
    const broadcast = req.app.get('broadcast');
    if (broadcast) broadcast({ type: 'DATA_RESET', data: {} });
    res.json({ success: true, message: 'All internal data cleared' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/admin/addresses
router.get('/addresses', async (req, res) => {
  const { page = 1, limit = 20, chain } = req.query;
  const filter = chain ? { chain: chain.toUpperCase() } : {};
  try {
    const total = await Address.countDocuments(filter);
    const addresses = await Address.find(filter)
      .sort({ createdAt: -1 })
      .skip((parseInt(page) - 1) * parseInt(limit))
      .limit(parseInt(limit));
    res.json({ total, page: parseInt(page), addresses });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/admin/transactions
router.get('/transactions', async (req, res) => {
  const { page = 1, limit = 20, status, chain } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (chain) filter.chain = chain.toUpperCase();
  try {
    const total = await Transaction.countDocuments(filter);
    const txs = await Transaction.find(filter)
      .sort({ timestamp: -1 })
      .skip((parseInt(page) - 1) * parseInt(limit))
      .limit(parseInt(limit));
    res.json({ total, page: parseInt(page), transactions: txs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
