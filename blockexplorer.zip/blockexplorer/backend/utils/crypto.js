const crypto = require('crypto');

// SHA256 hash
function sha256(data) {
  return crypto.createHash('sha256').update(data).digest('hex');
}

// Double SHA256 (Bitcoin style)
function dsha256(data) {
  return sha256(sha256(data));
}

// Generate txid from raw hex or random data
function generateTxid(rawHex) {
  const data = rawHex || crypto.randomBytes(64).toString('hex');
  return dsha256(data + Date.now().toString());
}

// Generate block hash
function generateBlockHash(height, previousHash, merkleRoot, timestamp, nonce) {
  const data = `${height}${previousHash}${merkleRoot}${timestamp}${nonce}`;
  return dsha256(data);
}

// Compute merkle root from array of txids
function computeMerkleRoot(txids) {
  if (!txids || txids.length === 0) return sha256('empty');
  if (txids.length === 1) return txids[0];

  let level = [...txids];
  while (level.length > 1) {
    const next = [];
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i];
      const right = level[i + 1] || left;
      next.push(dsha256(left + right));
    }
    level = next;
  }
  return level[0];
}

// ─── BTC-style Address Generation ─────────────────────────────────────────
// P2PKH legacy (1xxx) - simplified version
function generateBTCAddress() {
  const privateKey = crypto.randomBytes(32).toString('hex');
  // Simplified: use hash of random key as address bytes
  const pubKeyHash = sha256(privateKey).slice(0, 40);
  // Base58Check encoding (simplified - produces valid-looking address)
  const addressBytes = '00' + pubKeyHash;
  const checksum = dsha256(addressBytes).slice(0, 8);
  const fullHex = addressBytes + checksum;
  return '1' + hexToBase58(fullHex);
}

// Generate ETH/BSC address
function generateETHAddress() {
  const privateKey = crypto.randomBytes(32).toString('hex');
  const addressBytes = sha256(privateKey).slice(0, 40);
  const address = '0x' + addressBytes;
  return {
    address: toChecksumAddress(address),
    privateKey: '0x' + privateKey,
  };
}

// EIP-55 checksum address
function toChecksumAddress(address) {
  const addr = address.toLowerCase().replace('0x', '');
  const hash = sha256(addr);
  let result = '0x';
  for (let i = 0; i < addr.length; i++) {
    result += parseInt(hash[i], 16) >= 8 ? addr[i].toUpperCase() : addr[i];
  }
  return result;
}

// Simplified Base58 (Bitcoin alphabet)
const BASE58_CHARS = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
function hexToBase58(hex) {
  let num = BigInt('0x' + hex);
  let result = '';
  while (num > 0n) {
    result = BASE58_CHARS[Number(num % 58n)] + result;
    num = num / 58n;
  }
  return result.slice(0, 32); // Truncate for realistic length
}

// Generate WIF (Wallet Import Format) for BTC
function generateWIF() {
  const privKey = crypto.randomBytes(32).toString('hex');
  return {
    privateKey: privKey,
    wif: 'K' + hexToBase58('80' + privKey + '01'),
    address: generateBTCAddress(),
  };
}

// Generate fee estimate
function calculateFee(inputCount, outputCount, feeRatePerByte = 10) {
  // BTC: ~148 bytes per input, ~34 bytes per output, 10 bytes overhead
  const estimatedBytes = inputCount * 148 + outputCount * 34 + 10;
  const totalFee = estimatedBytes * feeRatePerByte;
  return {
    estimatedBytes,
    feeRateSatPerByte: feeRatePerByte,
    totalFeeSatoshis: totalFee,
    totalFeeBTC: totalFee / 1e8,
  };
}

module.exports = {
  sha256,
  dsha256,
  generateTxid,
  generateBlockHash,
  computeMerkleRoot,
  generateBTCAddress,
  generateETHAddress,
  generateWIF,
  calculateFee,
  toChecksumAddress,
};
