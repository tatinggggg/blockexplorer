const axios = require('axios');

const BTC_API = process.env.BTC_API_URL || 'https://blockstream.info/api';
const ETH_RPC = process.env.ETH_RPC_URL || 'https://cloudflare-eth.com';
const BSC_RPC = process.env.BSC_RPC_URL || 'https://bsc-dataseed.binance.org';

// ─── Bitcoin (Blockstream API) ─────────────────────────────────────────────
async function fetchBTCAddress(address) {
  const url = `${BTC_API}/address/${address}`;
  const res = await axios.get(url, { timeout: 10000 });
  const d = res.data;
  return {
    address,
    chain: 'BTC',
    balance: (d.chain_stats.funded_txo_sum - d.chain_stats.spent_txo_sum) / 1e8,
    totalReceived: d.chain_stats.funded_txo_sum / 1e8,
    totalSent: d.chain_stats.spent_txo_sum / 1e8,
    txCount: d.chain_stats.tx_count + d.mempool_stats.tx_count,
    source: 'rpc',
  };
}

async function fetchBTCTransaction(txid) {
  const url = `${BTC_API}/tx/${txid}`;
  const res = await axios.get(url, { timeout: 10000 });
  const d = res.data;
  return {
    txid: d.txid,
    chain: 'BTC',
    inputs: d.vin.map(v => ({
      txid: v.txid,
      vout: v.vout,
      address: v.prevout?.scriptpubkey_address || null,
      amount: (v.prevout?.value || 0) / 1e8,
      scriptSig: v.scriptsig || '',
      sequence: v.sequence,
    })),
    outputs: d.vout.map((o, i) => ({
      n: i,
      address: o.scriptpubkey_address || null,
      amount: o.value / 1e8,
      scriptPubKey: o.scriptpubkey || '',
    })),
    status: d.status.confirmed ? 'confirmed' : 'pending',
    confirmations: d.status.confirmed ? (d.status.block_height ? 1 : 0) : 0,
    blockHeight: d.status.block_height || null,
    blockHash: d.status.block_hash || null,
    fee: d.fee / 1e8,
    size: d.size,
    timestamp: d.status.block_time ? new Date(d.status.block_time * 1000) : new Date(),
    source: 'rpc',
  };
}

async function fetchBTCUTXO(address) {
  const url = `${BTC_API}/address/${address}/utxo`;
  const res = await axios.get(url, { timeout: 10000 });
  return res.data.map(u => ({
    txid: u.txid,
    vout: u.vout,
    address,
    chain: 'BTC',
    amount: u.value / 1e8,
    confirmations: u.status.confirmed ? 1 : 0,
    spent: false,
    blockHeight: u.status.block_height || null,
    source: 'rpc',
  }));
}

// ─── Ethereum / BSC (JSON-RPC) ─────────────────────────────────────────────
async function ethRPCCall(rpcUrl, method, params = []) {
  const res = await axios.post(rpcUrl, {
    jsonrpc: '2.0', id: 1, method, params,
  }, { timeout: 10000 });
  if (res.data.error) throw new Error(res.data.error.message);
  return res.data.result;
}

async function fetchETHAddress(address, chain = 'ETH') {
  const rpc = chain === 'BSC' ? BSC_RPC : ETH_RPC;
  const hexBalance = await ethRPCCall(rpc, 'eth_getBalance', [address, 'latest']);
  const hexTxCount = await ethRPCCall(rpc, 'eth_getTransactionCount', [address, 'latest']);
  const balance = parseInt(hexBalance, 16) / 1e18;
  const txCount = parseInt(hexTxCount, 16);
  return {
    address,
    chain,
    balance,
    txCount,
    totalReceived: balance,
    totalSent: 0,
    source: 'rpc',
  };
}

async function fetchETHTransaction(txid, chain = 'ETH') {
  const rpc = chain === 'BSC' ? BSC_RPC : ETH_RPC;
  const tx = await ethRPCCall(rpc, 'eth_getTransactionByHash', [txid]);
  if (!tx) throw new Error('Transaction not found');

  const receipt = await ethRPCCall(rpc, 'eth_getTransactionReceipt', [txid]).catch(() => null);
  const blockNum = tx.blockNumber ? parseInt(tx.blockNumber, 16) : null;
  const currentBlock = await ethRPCCall(rpc, 'eth_blockNumber', []).then(h => parseInt(h, 16)).catch(() => 0);

  return {
    txid,
    chain,
    from: tx.from,
    to: tx.to,
    value: parseInt(tx.value, 16) / 1e18,
    gasUsed: receipt ? parseInt(receipt.gasUsed, 16) : null,
    gasPrice: parseInt(tx.gasPrice, 16) / 1e9,
    nonce: parseInt(tx.nonce, 16),
    blockHeight: blockNum,
    blockHash: tx.blockHash,
    status: receipt ? (receipt.status === '0x1' ? 'confirmed' : 'failed') : 'pending',
    confirmations: blockNum ? currentBlock - blockNum + 1 : 0,
    inputs: [{ address: tx.from, amount: parseInt(tx.value, 16) / 1e18 }],
    outputs: [{ address: tx.to, amount: parseInt(tx.value, 16) / 1e18, n: 0 }],
    timestamp: new Date(),
    source: 'rpc',
  };
}

// ─── Public API dispatcher ─────────────────────────────────────────────────
async function fetchAddressFromRPC(chain, address) {
  switch (chain) {
    case 'BTC': return fetchBTCAddress(address);
    case 'ETH': return fetchETHAddress(address, 'ETH');
    case 'BSC': return fetchETHAddress(address, 'BSC');
    default: throw new Error(`Unsupported chain: ${chain}`);
  }
}

async function fetchTransactionFromRPC(chain, txid) {
  switch (chain) {
    case 'BTC': return fetchBTCTransaction(txid);
    case 'ETH': return fetchETHTransaction(txid, 'ETH');
    case 'BSC': return fetchETHTransaction(txid, 'BSC');
    default: throw new Error(`Unsupported chain: ${chain}`);
  }
}

async function fetchUTXOFromRPC(chain, address) {
  switch (chain) {
    case 'BTC': return fetchBTCUTXO(address);
    default: return [];
  }
}

module.exports = { fetchAddressFromRPC, fetchTransactionFromRPC, fetchUTXOFromRPC };
